Попарное тестирование полей login и password на сайте https://www.saucedemo.com/.
Сначала создадим пары, которые будем тестировать. 
Затем опишем все сценарии пользователей, на основе тестирования пар.
Получилось 18 пар

| № | user name |password |
| ------ | ------ |------ |
| 1 | standard_user|secret_sauce |
| 2 | locked_out_user|secret_sauce|
| 3 | problem_user|secret_sauce |
| 4 | performance_glitch_user |secret_sauce |
| 5 | standard_user| blank |
| 6 | locked_out_user| blank |
| 7 | problem_user| blank |
| 8 | performance_glitch_user | blank |
| 9 | standard_user   | wrong |
| 10 | locked_out_user  | wrong |
| 11 | problem_user  | wrong |
| 12 | performance_glitch_user | wrong |
| 13 | blank | secret_sauce |
| 14 | blank | blank |
| 15 | blank | wrong |
| 16 | wrong | secret_sauce |
| 17 | wrong | blank |
| 18 | wrong | wrong |

Тест-кейсы для 18 пар


Тест-кейс №1
Проверка поля авторизации

Предусловие: открыта страница авторизации  https://www.saucedemo.com/

Шаги: 
- в поле login ввести standard_user  
- в поле password ввести secret_sauce
- нажать кнопку Login

Ожидаемый результат:  успешная авторизация пользователя. Открылась страница магазина с товарами.

Тест-кейс №2

Проверка поля авторизации

Предусловие: открыта страница авторизации  https://www.saucedemo.com/

Шаги: 
- в поле login ввести locked_out_user
- в поле password ввести secret_sauce
- нажать кнопку Login

Ожидаемый результат: система выдает уведомление о блокировке пользователя Sorry, this user has been locked out.

Тест-кейс №3

Проверка поля авторизации

Предусловие: открыта страница авторизации  https://www.saucedemo.com/

Шаги: 
- в поле login ввести problem_user  
- в поле password ввести secret_sauce
- нажать кнопку Login

Ожидаемый результат: успешная авторизация пользователя. Открылась страница магазина с кривыми фото собаки

Тест-кейс №4

Проверка поля авторизации

Предусловие: открыта страница авторизации  https://www.saucedemo.com/

Шаги: 
- в поле login ввести performance_glitch_user 
- в поле password ввести secret_sauce
- нажать кнопку Login

Ожидаемый результат: успешная авторизация пользователя только после 2-3 нажатий по кнопке Login

Тест-кейс №5
Проверка поля авторизации
Предусловие: открыта страница авторизации  https://www.saucedemo.com/
Шаги: 
- в поле login ввести standard_user  
- в поле password оставить пустым
- нажать кнопку Login
Ожидаемый результат: система выдает сообщение об ошибке Password is required (введите пароль)

Тест-кейс №6
Проверка поля авторизации
Предусловие: открыта страница авторизации  https://www.saucedemo.com/
Шаги: 
- в поле login ввести stan locked_out_user    
 - в поле password оставить пустым
- нажать кнопку Login
Ожидаемый результат: система выдает сообщение об ошибке Password is required (введите пароль)

Тест-кейс №7
Проверка поля авторизации
Предусловие: открыта страница авторизации  https://www.saucedemo.com/
Шаги: 
- в поле login ввести problem_user
 - в поле password оставить пустым
- нажать кнопку Login
Ожидаемый результат: система выдает сообщение об ошибке Password is required (введите пароль)


Тест-кейс №8
Проверка поля авторизации
Предусловие: открыта страница авторизации  https://www.saucedemo.com/
Шаги: 
- в поле login ввести performance_glitch_user
 - в поле password оставить пустым
- нажать кнопку Login
Ожидаемый результат: система выдает сообщение об ошибке Password is required (введите пароль)

Тест-кейс №9
Проверка поля авторизации
Предусловие: открыта страница авторизации  https://www.saucedemo.com/
Шаги: 
- в поле login ввести standard_user
 - в поле password ввести любое значение, отличное от правильного пароля. 
Например cookie
- нажать кнопку Login
Ожидаемый результат: система выдает сообщение об ошибке – не правильный пароль
Username and password do not match any user in this service

Тест-кейс №10
Проверка поля авторизации
Предусловие: открыта страница авторизации  https://www.saucedemo.com/
Шаги: 
- в поле login ввести locked_out_user
 - в поле password ввести любое значение, отличное от правильного пароля. 
Например cookie
- нажать кнопку Login
Ожидаемый результат: система выдает сообщение об ошибке – не правильный пароль
Username and password do not match any user in this service

Тест-кейс №11
Проверка поля авторизации
Предусловие: открыта страница авторизации  https://www.saucedemo.com/
Шаги: 
- в поле login ввести problem_user
 - в поле password ввести любое значение, отличное от правильного пароля. 
Например cookie
- нажать кнопку Login
Ожидаемый результат: система выдает сообщение об ошибке – не правильный пароль
Username and password do not match any user in this service


Тест-кейс №12
Проверка поля авторизации
Предусловие: открыта страница авторизации  https://www.saucedemo.com/
Шаги: 
- в поле login ввести performance_glitch_user
 - в поле password ввести любое значение, отличное от правильного пароля. 
Например cookie
- нажать кнопку Login
Ожидаемый результат: система выдает сообщение об ошибке – не правильный пароль
Username and password do not match any user in this service

Тест-кейс №13
Проверка поля авторизации
Предусловие: открыта страница авторизации  https://www.saucedemo.com/
Шаги: 
- в поле login оставить пустым
 - в поле password ввести  secret_sauce
- нажать кнопку Login
Ожидаемый результат: система выдает ошибку – введите логин 
Username is required

Тест-кейс №14
Проверка поля авторизации
Предусловие: открыта страница авторизации  https://www.saucedemo.com/
Шаги: 
- в поле login оставить пустым
 - в поле password оставить пустым
- нажать кнопку Login
Ожидаемый результат: система выдает ошибку – введите логин и пароль, но система выдает ошибку только том, что нужно ввести логин - Username is required

Тест-кейс №15
Проверка поля авторизации
Предусловие: открыта страница авторизации  https://www.saucedemo.com/
Шаги: 
- в поле login оставить пустым
- в поле password ввести любое значение, отличное от правильного пароля. 
Например cookie
- нажать кнопку Login
Ожидаемый результат: система выдает ошибку – введите логин и пароль, но система выдает ошибку только том, что нужно ввести логин - Username is required

Тест-кейс №16
Проверка поля авторизации
Предусловие: открыта страница авторизации  https://www.saucedemo.com/
Шаги: 
- в поле login ввести любое значение кроме 
standard_user \ locked_out_user \ problem_user \ performance_glitch_user
- в поле password ввести secret_sauce
- нажать кнопку Login
Ожидаемый результат: система выдает ошибку – логин и пароль не совпадают - Username and password do not match any user in this service

Тест-кейс №17
Проверка поля авторизации
Предусловие: открыта страница авторизации  https://www.saucedemo.com/
Шаги: 
- в поле login ввести  в поле login ввести любое значение кроме 
standard_user \ locked_out_user \ problem_user \ performance_glitch_user
- в поле password оставить пустым

- нажать кнопку Login

Ожидаемый результат: система выдает ошибку –  введите пароль - Password is required

Тест-кейс №18
Проверка поля авторизации
Предусловие: открыта страница авторизации  https://www.saucedemo.com/
Шаги: 
- в поле login ввести  в поле login ввести любое значение кроме 
standard_user \ locked_out_user \ problem_user \ performance_glitch_user
- в поле password ввести любое значение, отличное от правильного пароля. 
- нажать кнопку Login
Ожидаемый результат: система выдает ошибку – логин и пароль не совпадают - Username and password do not match any user in this service


