### Тестирование мобильного приложения tutu.ru
```
Окружение: 
- iphone 7
- iOS - 15.7.3.
```

| | | | | | | | | | |
|-|-|-|-|-|-|-|-|-|-|
|Набор тестов|ID|Название|Результат теста|Ссылка на тест|Автоматизирован|Дата/время результата|Дефекты|
|Native testing|1|Регистрация по e-mail|Успешен|https://team-1zha.testit.software:443//projects/1/tests/3|Нет|19.07.2023 22:31:34| | |
|Native testing|2|зация в приложении |Успешен|https://team-1zha.testit.software:443//projects/1/tests/4|Нет|20.07.2023 09:33:57| | |
|Native testing|3|Заполнение данных в профиле|Успешен|https://team-1zha.testit.software:443//projects/1/tests/5|Нет|20.07.2023 09:33:57| | |
|Native testing|4|Скорость запуска приложения на устройстве|Провален|https://team-1zha.testit.software:443//projects/1/tests/6|Нет|20.07.2023 09:35:07| |занимает около 6 секунд|
|Native testing|5|Скорость обработки запросов|Провален|https://team-1zha.testit.software:443//projects/1/tests/7|Нет|20.07.2023 09:35:07| |обработка запроса занимает 10 секунд |
|Native testing|6|Добавление пассажиров в билет|Провален|https://team-1zha.testit.software:443//projects/1/tests/8|Нет|20.07.2023 09:35:07| |невозможно если их нет в профиле|
|Native testing|7|Обращение в поддержку|Успешен|https://team-1zha.testit.software:443//projects/1/tests/9|Нет|20.07.2023 09:33:57| | |
|Native testing|8|Добавление пассажиров в профиль пользователя (UX)|Провален|https://team-1zha.testit.software:443//projects/1/tests/10|Нет|20.07.2023 09:35:07| |невозможно если на них ранее не покупались билеты|
|Native testing|9|Зависимость от сети|Успешен|https://team-1zha.testit.software:443//projects/1/tests/11|Нет|20.07.2023 09:35:34| | |
|Native testing|10|Поиск билетов из А в Б|Успешен|https://team-1zha.testit.software:443//projects/1/tests/12|Нет|20.07.2023 09:33:57| | |
|Native testing|11|Просмотр контента по виджету "границы и ограничения"|Успешен|https://team-1zha.testit.software:443//projects/1/tests/13|Нет|20.07.2023 09:33:57| | |
|Native testing|12|Оплата заказа банковской картой|Успешен|https://team-1zha.testit.software:443//projects/1/tests/14|Нет|20.07.2023 09:33:57| | |
|Native testing|13|Поиск отеля-гостиницы|Успешен|https://team-1zha.testit.software:443//projects/1/tests/15|Нет|20.07.2023 09:33:57| | |
|Native testing|14|Смена языка (локализация)|Провален|https://team-1zha.testit.software:443//projects/1/tests/16|Нет|20.07.2023 09:35:07| |большая часть остается на русском |
|Native testing|15|Переход в чат Telegram|Успешен|https://team-1zha.testit.software:443//projects/1/tests/18|Нет|20.07.2023 09:33:57| | |
|Native testing|16|Поделиться контентом приложения |Успешен|https://team-1zha.testit.software:443//projects/1/tests/19|Нет|20.07.2023 09:33:57| | |
|Native testing|17|Поиск билета на автобус|Успешен|https://team-1zha.testit.software:443//projects/1/tests/20|Нет|20.07.2023 09:33:57| | |
|Native testing|18|Использование фильтров в результатах поиска|Успешен|https://team-1zha.testit.software:443//projects/1/tests/23|Нет|20.07.2023 09:33:57| | |
|Native testing|19|Сортировка результатов поиска |Успешен|https://team-1zha.testit.software:443//projects/1/tests/24|Нет|20.07.2023 09:33:57| | |
|Native testing|20|Просмотр заказов|Успешен|https://team-1zha.testit.software:443//projects/1/tests/25|Нет|20.07.2023 09:33:57| | |
|Native testing|21|Написать разработчикам|Успешен|https://team-1zha.testit.software:443//projects/1/tests/26|Нет|20.07.2023 09:33:57| | |
|Native testing|22|Функция уведомлений|Успешен|https://team-1zha.testit.software:443//projects/1/tests/27|Нет|20.07.2023 09:33:57| | |
|Native testing|23|Работа с приложением при заряде батареи 9%|Успешен|https://team-1zha.testit.software:443//projects/1/tests/28|Нет|20.07.2023 09:33:57| | |
|Native testing|24|Прерывание работы с приложением телефонным звонком|Успешен|https://team-1zha.testit.software:443//projects/1/tests/29|Нет|20.07.2023 09:33:57| | |
|Native testing|25|Прерывание работы срабатыванием будильника|Успешен|https://team-1zha.testit.software:443//projects/1/tests/30|Нет|20.07.2023 09:33:57| | |
|Native testing|26|Темная тема|Провален|https://team-1zha.testit.software:443//projects/1/tests/31|Нет|20.07.2023 09:35:07| |стартовая страница остается дневной темой|
|Native testing|27|Поиск по разделу "Справочная"|Успешен|https://team-1zha.testit.software:443//projects/1/tests/32|Нет|20.07.2023 09:33:57| | |
|Native testing|28|Виджеты: идеи для поездок|Успешен|https://team-1zha.testit.software:443//projects/1/tests/33|Нет|20.07.2023 09:33:57| | |
|Native testing|29| Вернуть или обменять билет|Успешен|https://team-1zha.testit.software:443//projects/1/tests/34|Нет|20.07.2023 09:33:57| | |
|Native testing|30|Виджет: ответы на частые вопросы|Успешен|https://team-1zha.testit.software:443//projects/1/tests/35|Нет|20.07.2023 09:33:57| | |
|Native testing|31|Работа приложения в авиа-режиме|Успешен|https://team-1zha.testit.software:443//projects/1/tests/36|Нет|20.07.2023 09:33:57| | |
|Native testing|32|Смена пароля учетной записи|Провален|https://team-1zha.testit.software:443//projects/1/tests/37|Нет|20.07.2023 09:35:07| |только код на имейл можно |
|Native testing|33|Выход из приложения, log out|Успешен|https://team-1zha.testit.software:443//projects/1/tests/38|Нет|20.07.2023 09:33:57| | |
|Native testing|34|Удаление личных данных по ссылке "удалить профиль"|Провален|https://team-1zha.testit.software:443//projects/1/tests/39|Нет|20.07.2023 09:35:07| |данные сохраняются|
|Native testing|35|Удаление учетной записи (аккаунта) из приложения |Провален|https://team-1zha.testit.software:443//projects/1/tests/40|Нет|20.07.2023 09:35:07| |профиль сохраняется |
|Native testing|36|Удаление\редактирование личных данных через редактирование профиля|Успешен|https://team-1zha.testit.software:443//projects/1/tests/41|Нет|20.07.2023 09:33:57| | |
