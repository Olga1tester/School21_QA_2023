Проект 5,
упражнение 5
# Swagger

Опиши все возможные запросы (27 эндпоинтов). 
Для GET-запроса с указанием {id} в запросе, а также для каждого PUT- или POST- запроса требуется описать два случая:

•	успешный, когда сервер обрабатывает полученные данные без ошибки;

•	провальный, когда сервер обрабатывает полученные данные с ошибками (к примеру, возвращает 400 ошибку)

P.S.: итого нужно описать 44 отправленных запроса.

Requests (запросы)

## **Activities** 
1.	### HTTP-method: GET /api/v1/Activities

- URL of request: https://fakerestapi.azurewebsites.net/api/v1/Activities
- Header of the request: -H  "accept: text/plain; v=1.0"
- Body of the request: none
- CODE of response: 200 
- Body of the response:  
 {
    "id": 5,
    "title": "Activity 5",
    "dueDate": "2023-07-13T12:21:12.6830145+00:00",
    "completed": false
  },

2.  ### HTTP-метод: GET ID ​/api​/v1​/Activities​/{15} 
 - Полный URL запроса: https://fakerestapi.azurewebsites.net/api/v1/Activities/15 
- Заголовки запроса:  -H  "accept: text/plain; v=1.0"
- Тело запроса (при наличии):
- Статус-код ответа: 200
- Тело ответа:{
  "id": 15,
  "title": "Activity 15",
  "dueDate": "2023-07-14T00:36:40.057432+00:00",
  "completed": false
}

3.  ### HTTP-метод: GET ID FAILED ​/api​/v1​/Activities​/{1560000000000000000009} 
 - Полный URL запроса: https://fakerestapi.azurewebsites.net/api/v1/Activities/1560000000000000000009
- Заголовки запроса:  -H  "accept: text/plain; v=1.0"
- Тело запроса (при наличии):
- Статус-код ответа: 400
- Тело ответа: {
  "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
  "title": "One or more validation errors occurred.",
  "status": 400,
  "traceId": "00-56dd749d77d2cc4aa50fb386c6cc65a9-6e5b245efcb16a40-00",
  "errors": {
    "id": [
      "The value '1560000000000000000009' is not valid."
    ]
  }
}

4.  ### HTTP-метод: PUT ID FAILED /api/v1/Activities/{889222222222222222222222222222222222222228955}
 - Полный URL запроса: https://fakerestapi.azurewebsites.net/api/v1/Activities
- Заголовки запроса:  
- -H  "accept: text/plain; v=1.0" -H  "Content-Type: application/json; v=1.0" -d "{\"id\":8.892222222222223e+44,\"title\":\"string\",\"dueDate\":\"2023-07-13T09:08:21.220Z\",\"completed\":true}" 
- - Тело запроса (при наличии): 
- {
  "id": 889222222222222222222222222222222222222228955,
  "title": "string",
  "dueDate": "2023-07-13T09:08:21.220Z",
  "completed": true
}
- Статус-код ответа: 400 Bad request (undocumented)
- Тело ответа:
- {
  "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
  "title": "One or more validation errors occurred.",
  "status": 400,
  "traceId": "00-1607e6990bdc434299e6d76bd9f86d72-eb736f805836334d-00",
  "errors": {
    "$.id": [
      "The JSON value could not be converted to System.Int32. Path: $.id | LineNumber: 0 | BytePositionInLine: 27."
    ]
  
5.  ## HTTP-метод: PUT ID ​/api​/v1​/Activities​/{6} 
 - Полный URL запроса: https://fakerestapi.azurewebsites.net/api/v1/Activities/6 
 - 
- Заголовки запроса: -H  "accept: text/plain; v=1.0" -H  "Content-Type: application/json; v=1.0" -d "{\"id\":6,\"title\":\"string\",\"dueDate\":\"2023-07-13T09:28:34.821Z\",\"completed\":true}" 
- 
- Тело запроса (при наличии):
-  {
  "id": 6,
  "title": "string",
  "dueDate": "2023-07-13T09:28:34.821Z",
  "completed": true
}
- Статус-код ответа: 200
- Тело ответа: 
- {
  "id": 6,
  "title": "string",
  "dueDate": "2023-07-13T09:28:34.821Z",
  "completed": true
}


6. ### HTTP-метод: PUT ​/api​/v1​/Activities​/
 - Полный URL запроса: https://fakerestapi.azurewebsites.net/api/v1/Activities
- Заголовки запроса:
    -H  "accept: text/plain; v=1.0" -H  "Content-Type: application/json; v=1.0" -d "{\"id\":0,\"title\":\"string\",\"dueDate\":\"2023-07-13T09:08:21.220Z\",\"completed\":true}"
- Тело запроса (при наличии):
- Статус-код ответа: 200
- Тело ответа: 	
{
  "id": 0,
  "title": "string",
  "dueDate": "2023-07-13T09:08:21.22Z",
  "completed": true


7.  ## HTTP-метод: POST ID FAILED ​/api​/v1​/Activities​/{889222222222222222222222222222222222222228955} 
 - Полный URL запроса: https://fakerestapi.azurewebsites.net/api/v1/Activities
- Заголовки запроса: -H  "accept: text/plain; v=1.0" -H  "Content-Type: application/json; v=1.0" -d "{\"id\":8.892222222222223e+44,\"title\":\"string\",\"dueDate\":\"2023-07-13T09:08:21.220Z\",\"completed\":true}"
- Тело запроса (при наличии): {
  "id": 889222222222222222222222222222222222222228955,
  "title": "string",
  "dueDate": "2023-07-13T09:08:21.220Z",
  "completed": true
}
- Статус-код ответа: 400 
- Тело ответа: {
  "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
  "title": "One or more validation errors occurred.",
  "status": 400,
  "traceId": "00-713ec6b99ce8ec468d97f5d8671bfeca-2c8b82750426e04e-00",
  "errors": {
    "$.id": [
      "The JSON value could not be converted to System.Int32. Path: $.id | LineNumber: 0 | BytePositionInLine: 27."
    ]

8.  ## HTTP-метод: POST ID ​/api​/v1​/Activities​/{52} 
 - Полный URL запроса: https://fakerestapi.azurewebsites.net/api/v1/Activities
- Заголовки запроса: -H  "accept: text/plain; v=1.0" -H  "Content-Type: application/json; v=1.0" -d "{\"id\":52,\"title\":\"string\",\"dueDate\":\"2023-07-13T09:08:21.220Z\",\"completed\":true}"
- Тело запроса (при наличии): {
  "id": 52,
  "title": "string",
  "dueDate": "2023-07-13T09:08:21.220Z",
  "completed": true
}
- Статус-код ответа: 200
- Тело ответа: 	
{
  "id": 52,
  "title": "string",
  "dueDate": "2023-07-13T09:08:21.22Z",
  "completed": true
}

9.  ## HTTP-метод: DELETE ID ​/api​/v1​/Activities​/{200} 
 - Полный URL запроса: https://fakerestapi.azurewebsites.net/api/v1/Activities/66
- Заголовки запроса:  -H  "accept: */*"
- Тело запроса (при наличии):
- Статус-код ответа: 200
- Тело ответа:  


## **Authors** /api/v1/Authors

10.  ## HTTP-метод: GET ​/api​/v1​/Authors

 - Полный URL запроса: https://fakerestapi.azurewebsites.net/api/v1/Authors
- Заголовки запроса:  -H  "accept: text/plain; v=1.0"
- Тело запроса (при наличии):
- Статус-код ответа: 200
- Тело ответа:[
  {
    "id": 1,
    "idBook": 1,
    "firstName": "First Name 1",
    "lastName": "Last Name 1"
  },
  {
    "id": 2,
    "idBook": 1,
    "firstName": "First Name 2",
    "lastName": "Last Name 2"
  },
  {


11.  ## HTTP-метод: POST ​ID /api​/v1​/Authors/{10}
 - Полный URL запроса: https://fakerestapi.azurewebsites.net/api/v1/Authors
- Заголовки запроса:  -H  "accept: text/plain; v=1.0" -H  "Content-Type: application/json; v=1.0" -d "{\"id\":10,\"idBook\":0,\"firstName\":\"string\",\"lastName\":\"string\"}"
- Тело запроса (при наличии):  {
  "id": 10,
  "idBook": 0,
  "firstName": "string",
  "lastName": "string"
}
- Статус-код ответа: 200
- Тело ответа: {
  "id": 10,
  "idBook": 0,
  "firstName": "string",
  "lastName": "string"
}

12. ## HTTP-метод: POST FAILED ​/api​/v1​/Authors/{0,65}

 - Полный URL запроса:https://fakerestapi.azurewebsites.net/api/v1/Authors
- Заголовки запроса: -H  "accept: text/plain; v=1.0" -H  "Content-Type: application/json; v=1.0" -d "{\"id\":0.67,\"idBook\":0,\"firstName\":\"string\",\"lastName\":\"string\"}"
- Тело запроса (при наличии): {
  "id": 0.67,
  "idBook": 0,
  "firstName": "string",
  "lastName": "string"
}
- Статус-код ответа: 400
- Тело ответа: {
  "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
  "title": "One or more validation errors occurred.",
  "status": 400,
  "traceId": "00-e50b31c52084a94ea824838f7a59fea8-222285466087a347-00",
  "errors": {
    "$.id": [
      "The JSON value could not be converted to System.Int32. Path: $.id | LineNumber: 0 | BytePositionInLine: 10."
    ]
  }
}

13. ## HTTP-метод: GET IDBook /api/v1/Authors/authors/books/{89}
 - Полный URL запроса: https://fakerestapi.azurewebsites.net/api/v1/Authors/authors/books/89
- Заголовки запроса:-H  "accept: text/plain; v=1.0"
- Тело запроса (при наличии):
- Статус-код ответа: 200
- Тело ответа: [
  {
    "id": 283,
    "idBook": 89,
    "firstName": "First Name 283",
    "lastName": "Last Name 283"
  },

14. ## HTTP-метод: GET ID  ​​/api​/v1​/Authors​/{9}
- Полный URL запроса:https://fakerestapi.azurewebsites.net/api/v1/Authors/9
- Заголовки запроса:-H  "accept: text/plain; v=1.0"
- Тело запроса (при наличии):
- Статус-код ответа: 200
- Тело ответа: {
  "id": 9,
  "idBook": 3,
  "firstName": "First Name 9",
  "lastName": "Last Name 9"
}



16. ## HTTP-метод: GET IDBook FAILED /api/v1/Authors/authors/books/{109101010190000}
- Полный URL запроса: https://fakerestapi.azurewebsites.net/api/v1/Authors/authors/books/109101010190000
- Заголовки запроса: -H  "accept: text/plain; v=1.0"
- Тело запроса (при наличии): 
- Статус-код ответа: 400
- Тело ответа:{
  "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
  "title": "One or more validation errors occurred.",
  "status": 400,
  "traceId": "00-470b2703924a6642b7ef1c24b8d094e0-7b23a42c4c3dd545-00",
  "errors": {
    "idBook": [
      "The value '109101010190000' is not valid."
    ]
  }
}

17. ## HTTP-метод: GET ID Author FAiled /api/v1/Authors/{9899662047}
- Полный URL запроса:https://fakerestapi.azurewebsites.net/api/v1/Authors/9899662047
- Заголовки запроса:-H  "accept: text/plain; v=1.0"
- Тело запроса (при наличии):
- Статус-код ответа: 400
- Тело ответа:{
  "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
  "title": "One or more validation errors occurred.",
  "status": 400,
  "traceId": "00-1941ddd2e5c4e14cb299dd73eab4d6b2-17ceb35e4fc63445-00",
  "errors": {
    "id": [
      "The value '9899662047' is not valid."
    ]
  }
}

18. ## HTTP-метод: PUT /api/v1/Authors/{632}
- Полный URL запроса: https://fakerestapi.azurewebsites.net/api/v1/Authors/632
- Заголовки запроса: -H  "accept: text/plain; v=1.0" -H  "Content-Type: application/json; v=1.0" -d "{\"id\":632,\"idBook\":0,\"firstName\":\"string\",\"lastName\":\"string\"}"
- Тело запроса (при наличии): {
  "id": 632,
  "idBook": 0,
  "firstName": "string",
  "lastName": "string"
}
- Статус-код ответа: 200
- Тело ответа:
- {
  "id": 632,
  "idBook": 0,
  "firstName": "string",
  "lastName": "string"
}

19. ## HTTP-метод: PUT FAILED /api/v1/Authors/{6329090909}
- Полный URL запроса: https://fakerestapi.azurewebsites.net/api/v1/Authors/6329090909 
- Заголовки запроса: -H  "accept: text/plain; v=1.0" -H  "Content-Type: application/json; v=1.0" -d "{\"id\":6329090909,\"idBook\":0,\"firstName\":\"string\",\"lastName\":\"string\"}"
- Тело запроса (при наличии):{
  "id": 6329090909,
  "idBook": 0,
  "firstName": "string",
  "lastName": "string"
}
- Статус-код ответа: 400
- Тело ответа: {
  "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
  "title": "One or more validation errors occurred.",
  "status": 400,
  "traceId": "00-e23b774c800ba744b7d440a3a7e02a2f-595b9dcbd880024b-00",
  "errors": {
    "id": [
      "The value '6329090909' is not valid."
    ],
    "$.id": [
      "The JSON value could not be converted to System.Int32. Path: $.id | LineNumber: 0 | BytePositionInLine: 16."
    ]
  }
}

20. ## HTTP-метод: DELETE /api/v1/Authors/{5} 
- Полный URL запроса: https://fakerestapi.azurewebsites.net/api/v1/Authors/5
- Заголовки запроса: -H "accept: */*"
- Тело запроса (при наличии):
- Статус-код ответа: 200
- Тело ответа:
-  access-control-allow-origin: * 
 api-supported-versions: 1.0 
 content-length: 0 
 date: Thu13 Jul 2023 11:08:46 GMT 
 server: Kestrel 

21. ## HTTP-метод: DELETE FAILED /api/v1/Authors/{565898674444}
- Полный URL запроса: https://fakerestapi.azurewebsites.net/api/v1/Authors/565898674444
- Заголовки запроса: -H  "accept: */*"
- Тело запроса (при наличии):
- Статус-код ответа: 400
- Тело ответа: {
  "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
  "title": "One or more validation errors occurred.",
  "status": 400,
  "traceId": "00-cec15d49c2568447a0ac6be95be6235a-2764e81d3358954d-00",
  "errors": {
    "id": [
      "The value '565898674444' is not valid."
    ]
  }


# Books

22.   ## HTTP-метод: POST FAILED /api/v1/Books/{5,0}
 - Полный URL запроса: https://fakerestapi.azurewebsites.net/api/v1/Books
- Заголовки запроса:  -H  "accept: */*" -H  "Content-Type: application/json; v=1.0" -d "{  \"id\": 5,0,  \"title\": \"string\",  \"description\": \"string\",  \"pageCount\": 0,  \"excerpt\": \"string\",  \"publishDate\": \"2023-07-13T09:54:17.417Z\"}"
- Тело запроса (при наличии): {
 }
  "id": 5,0,
  "title": "string",
  "description": "string",
  "pageCount": 0,
  "excerpt": "string",
  "publishDate": "2023-07-13T09:54:17.417Z"
}
- Статус-код ответа: 400
- Тело ответа: {
  "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
  "title": "One or more validation errors occurred.",
  "status": 400,
  "traceId": "00-07444f7e03b6fe49be1702d5134cba72-0c1079caa8d19d4e-00",
  "errors": {
    "$": [
      "'0' is an invalid start of a property name. Expected a '\"'. Path: $ | LineNumber: 1 | BytePositionInLine: 10."
    ]
  
23.  ## HTTP-метод: PUT ID /api/v1/Books/{41}
 - Полный URL запроса: https://fakerestapi.azurewebsites.net/api/v1/Books/41
- Заголовки запроса: -H  "accept: */*" -H  "Content-Type: application/json; v=1.0" -d "{\"id\":41,\"title\":\"string\",\"description\":\"string\",\"pageCount\":0,\"excerpt\":\"string\",\"publishDate\":\"2023-07-13T10:06:37.776Z\"}"
Request URL
- Тело запроса (при наличии):  {
  "id": 41,
  "title": "string",
  "description": "string",
  "pageCount": 0,
  "excerpt": "string",
  "publishDate": "2023-07-13T10:06:37.776Z"
}
- Статус-код ответа: 200
- Тело ответа: 	
{
  "id": 41,
  "title": "string",
  "description": "string",
  "pageCount": 0,
  "excerpt": "string",
  "publishDate": "2023-07-13T10:06:37.776Z"
}

24.  ## HTTP-метод: PUT ID FAILED /api/v1/Books/{0666699955}
- Полный URL запроса: https://fakerestapi.azurewebsites.net/api/v1/Books/0666699955 
- Заголовки запроса: -H  "Content-Type: application/json; v=1.0" -d "{  \"id\": 0666699955,  \"title\": \"string\",  \"description\": \"string\",  \"pageCount\": 0,  \"excerpt\": \"string\",  \"publishDate\": \"2023-07-13T10:06:37.776Z\"}"
- Тело запроса (при наличии): {
  "id": 0666699955,
  "title": "string",
  "description": "string",
  "pageCount": 0,
  "excerpt": "string",
  "publishDate": "2023-07-13T10:06:37.776Z"
}
- Статус-код ответа: 400
- Тело ответа: {
  "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
  "title": "One or more validation errors occurred.",
  "status": 400,
  "traceId": "00-c7b8fe56219fdf439b1a777e012421f7-daa0fa1f1bc88648-00",
  "errors": {
    "$.id": [
      "Invalid leading zero before '6'. Path: $.id | LineNumber: 1 | BytePositionInLine: 9."
    ]
  
25.  ## HTTP-метод: GET ID FAILED /api/v1/Books/{92000000000001}
 - Полный URL запроса: https://fakerestapi.azurewebsites.net/api/v1/Books/92000000000001
- Заголовки запроса: -H  "accept: text/plain; v=1.0"
- Тело запроса (при наличии):
- Статус-код ответа: 400
- Тело ответа: {
  "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
  "title": "One or more validation errors occurred.",
  "status": 400,
  "traceId": "00-511cf4f703f02d429174d49e8b847d97-1bc1f3144f67764b-00",
  "errors": {
    "id": [
      "The value '92000000000001' is not valid."
    ]

26.    ## HTTP-метод: GET ID /api/v1/Books/{92}
​/api​/v1​/Books​/{id} 
 - Полный URL запроса: https://fakerestapi.azurewebsites.net/api/v1/Books/92
- Заголовки запроса: curl -X GET "https://fakerestapi.azurewebsites.net/api/v1/Books/92" -H  "accept: text/plain; v=1.0"
- Тело запроса (при наличии):
- Статус-код ответа: 200
- Тело ответа: {
  "id": 92,
  "title": "Book 92",
  "description": "Lorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\n",
  "pageCount": 9200,
  "excerpt": "Lorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\n",
  "publishDate": "2023-04-12T09:57:10.6550591+00:00"
}

27.   ## HTTP-метод: POST /api/v1/Books/{55850}
 - Полный URL запроса:https://fakerestapi.azurewebsites.net/api/v1/Books
- Заголовки запроса:-H  "Content-Type: application/json; v=1.0" -d "{\"id\":55850,\"title\":\"string\",\"description\":\"string\",\"pageCount\":0,\"excerpt\":\"string\",\"publishDate\":\"2023-07-13T11:15:45.410Z\"}"
- Тело запроса (при наличии): {
  "id": 55850,
  "title": "string",
  "description": "string",
  "pageCount": 0,
  "excerpt": "string",
  "publishDate": "2023-07-13T11:15:45.410Z"
}
- Статус-код ответа: 200
- Тело ответа:
  "id": 55850,
  "title": "string",
  "description": "string",
  "pageCount": 0,
  "excerpt": "string",
  "publishDate": "2023-07-13T11:15:45.41Z"
}


28.  ## HTTP-метод: GET /api/v1/Books
 - Полный URL запроса: https://fakerestapi.azurewebsites.net/api/v1/Books
- Заголовки запроса: -H  "accept: text/plain; v=1.0"
- Тело запроса (при наличии):
- Статус-код ответа: 200
- Тело ответа:
[
  {
    "id": 1,
    "title": "Book 1",
    "description": "Lorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\n",
    "pageCount": 100,
    "excerpt": "Lorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\n",
    "publishDate": "2023-07-12T11:22:48.0546795+00:00"
  },
  {
    "id": 2,
    "title": "Book 2",
    "description": "Lorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\n",
    "pageCount": 200,
    "excerpt": "Lorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\n",
    "publishDate": "2023-07-11T11:22:48.0546956+00:00"
  },
29.  ## HTTP-метод: DELETE ​/api​/v1​/Books​/{94}
- Полный URL запроса: https://fakerestapi.azurewebsites.net/api/v1/Books/94
- Заголовки запроса: -H  "accept: */*"
- Тело запроса (при наличии):
- Статус-код ответа: 200
- Тело ответа:  access-control-allow-origin: * 
 api-supported-versions: 1.0 
 content-length: 0 
 date: Thu13 Jul 2023 11:24:21 GMT 
 server: Kestrel 

# Cover Photos

30.  ## HTTP-метод: GET /api/v1/CoverPhotos
 - Полный URL запроса: https://fakerestapi.azurewebsites.net/api/v1/CoverPhotos
- Заголовки запроса: https://fakerestapi.azurewebsites.net/api/v1/CoverPhotos
- Тело запроса (при наличии):
- Статус-код ответа: 200
- Тело ответа: [
  {
    "id": 1,
    "idBook": 1,
    "url": "https://placeholdit.imgix.net/~text?txtsize=33&txt=Book 1&w=250&h=350"
  },
  {
    "id": 2,
    "idBook": 2,
    "url": "https://placeholdit.imgix.net/~text?txtsize=33&txt=Book 2&w=250&h=350"
  },


31.  ## HTTP-метод: POST  /api/v1/CoverPhotos
 - Полный URL запроса: https://fakerestapi.azurewebsites.net/api/v1/CoverPhotos
- Заголовки запроса: -H  "accept: text/plain; v=1.0" -H  "Content-Type: application/json; v=1.0" -d "{\"id\":5,\"idBook\":0,\"url\":\"string\"}"
- Тело запроса (при наличии):   "id": 5,
  "idBook": 0,
  "url": "string"
}
- Статус-код ответа: 200
- Тело ответа:
{
  "id": 5,
  "idBook": 0,
  "url": "string"
}


32.  ## HTTP-метод: POST ​/api​/v1​/CoverPhotos/{0000009333335}
 - Полный URL запроса: https://fakerestapi.azurewebsites.net/api/v1/CoverPhotos
- Заголовки запроса:-H  "accept: text/plain; v=1.0" -H  "Content-Type: application/json; v=1.0" -d "{  \"id\"000000 9333335,  \"idBook\": 0,  \"url\": \"string\"}"
- Тело запроса (при наличии): {
  "id"000000 9333335,
  "idBook": 0,
  "url": "string"
}
- Статус-код ответа: 400
- Тело ответа:
{
  "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
  "title": "One or more validation errors occurred.",
  "status": 400,
  "traceId": "00-594930f345ad354eb061097f3a717fb5-8c08b9bf752a1e46-00",
  "errors": {
    "$": [
      "'0' is invalid after a property name. Expected a ':'. Path: $ | LineNumber: 1 | BytePositionInLine: 6."
    ]
  }

33.  ## HTTP-метод: GET ​/api​/v1​/CoverPhotos​/books​/covers​/{80}
 - Полный URL запроса: https://fakerestapi.azurewebsites.net/api/v1/CoverPhotos/books/covers/80
- Заголовки запроса: -H  "accept: text/plain; v=1.0"
- Тело запроса (при наличии): 
- Статус-код ответа:200
- Тело ответа: [
  {
    "id": 80,
    "idBook": 80,
    "url": "https://placeholdit.imgix.net/~text?txtsize=33&txt=Book 80&w=250&h=350"
  }
]

34.  ## HTTP-метод: GET ​/api​/v1​/CoverPhotos​/books​/covers​/{8000888888}
 - Полный URL запроса: https://fakerestapi.azurewebsites.net/api/v1/CoverPhotos/books/covers/8000888888
- Заголовки запроса: -H  "accept: text/plain; v=1.0"
- Тело запроса (при наличии):
- Статус-код ответа: 400
- Тело ответа: {
  "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
  "title": "One or more validation errors occurred.",
  "status": 400,
  "traceId": "00-2d30855a8b59c848b604302368aaba16-79c7fb5e63effb42-00",
  "errors": {
    "idBook": [
      "The value '8000888888' is not valid."
    ]
  
35.  ## HTTP-метод: GET ​/api​/v1​/CoverPhotos​/{17}
 - Полный URL запроса: https://fakerestapi.azurewebsites.net/api/v1/CoverPhotos/17
- Заголовки запроса: -H  "accept: text/plain; v=1.0"
- Тело запроса (при наличии):
- Статус-код ответа:200
- Тело ответа: 
{
  "id": 17,
  "idBook": 17,
  "url": "https://placeholdit.imgix.net/~text?txtsize=33&txt=Book 17&w=250&h=350"
}


36.  ## HTTP-метод: GET ​/api​/v1​/CoverPhotos​/{17222222222220}
 - Полный URL запроса: https://fakerestapi.azurewebsites.net/api/v1/CoverPhotos/17222222222220
- Заголовки запроса:  -H  "accept: text/plain; v=1.0"
- Тело запроса (при наличии):
- Статус-код ответа: 400
- Тело ответа: {
  "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
  "title": "One or more validation errors occurred.",
  "status": 400,
  "traceId": "00-1a1812d3b879f04aa4afa08e99f0b6ee-297b431f63f1cb48-00",
  "errors": {
    "id": [
      "The value '17222222222220' is not valid."
    ]

37.  ## HTTP-метод: PUT ​/api​/v1​/CoverPhotos​/{212}
 - Полный URL запроса: https://fakerestapi.azurewebsites.net/api/v1/CoverPhotos/212
- Заголовки запроса: -H  "accept: text/plain; v=1.0" -H  "Content-Type: application/json; v=1.0" -d "
 - Тело запроса (при наличии): {
  "id":212,
  "idBook": 0,
  "url": "string"
}
- Статус-код ответа: 200
- Тело ответа: {
  "id": 212,
  "idBook": 0,
  "url": "string"
}


38.  ## HTTP-метод: PUT ​/api​/v1​/CoverPhotos​/{21888888888888880}
 - Полный URL запроса: https://fakerestapi.azurewebsites.net/api/v1/CoverPhotos/21888888888888882
- Заголовки запроса: -H  "accept: text/plain; v=1.0" -H  "Content-Type: application/json; v=1.0" -d "{\"id\":21888888888888880,\"idBook\":0,\"url\":\"string\"}"
- Тело запроса (при наличии):
- Статус-код ответа: 400
- Тело ответа:
{
  "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
  "title": "One or more validation errors occurred.",
  "status": 400,
  "traceId": "00-788ae5bf831c1248902ffb492ee419aa-56f2de57505a3340-00",
  "errors": {
    "id": [
      "The value '21888888888888882' is not valid."
    ],
    "$.id": [
      "The JSON value could not be converted to System.Int32. Path: $.id | LineNumber: 0 | BytePositionInLine: 23."
    ]
  }
}

39.  ## HTTP-метод: DELETE ​/api​/v1​/CoverPhotos​/{66}
 - Полный URL запроса: https://fakerestapi.azurewebsites.net/api/v1/CoverPhotos/66
- Заголовки запроса: -H  "accept: */*"
- Тело запроса (при наличии):
- Статус-код ответа: 200
- Тело ответа: success

# Users 
40. ## HTTP-метод: GET ​/api​/v1​/Users
- Полный URL запроса: https://fakerestapi.azurewebsites.net/api/v1/Users
- Заголовки запроса: -H  "accept: text/plain; v=1.0"
- Тело запроса (при наличии):
- Статус-код ответа:200
- Тело ответа:
- [
  {
    "id": 1,
    "userName": "User 1",
    "password": "Password1"
  },
  {
    "id": 2,
    "userName": "User 2",
    "password": "Password2"
  },
  {
    "id": 3,
    "userName": "User 3",
    "password": "Password3"
  },
  {

41.  ## HTTP-метод: POST ​/api​/v1​/Users
 - Полный URL запроса: https://fakerestapi.azurewebsites.net/api/v1/Users
- Заголовки запроса: -H  "Content-Type: application/json; v=1.0" -d "{\"id\":10,\"userName\":\"string\",\"password\":\"string\"}"
- Тело запроса (при наличии): {
  "id": 10,
  "userName": "string",
  "password": "string"
}
- Статус-код ответа: 200
- Тело ответа:
- {
  "id": 10,
  "userName": "string",
  "password": "string"
}

42.   ## HTTP-метод: POST FAILED ​/api​/v1​/Users
 - Полный URL запроса: https://fakerestapi.azurewebsites.net/api/v1/Users
- Заголовки запроса: -H  "Content-Type: application/json; v=1.0" -d "{  \"id\": 0,10,  \"userName\": \"string\",  \"password\": \"string\"}"
- Тело запроса (при наличии): {
  "id": 0,10,
  "userName": "string",
  "password": "string"
}
- Статус-код ответа: 400
- Тело ответа: 
- {
  "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
  "title": "One or more validation errors occurred.",
  "status": 400,
  "traceId": "00-fada9f9969a8ee44a081ee835e55ffda-359e99b484ce5747-00",
  "errors": {
    "$": [
      "'1' is an invalid start of a property name. Expected a '\"'. Path: $ | LineNumber: 1 | BytePositionInLine: 10."
    ]
  }
}

43.  ## HTTP-метод: GET ​/api​/v1​/Users​/{8}
 - Полный URL запроса: https://fakerestapi.azurewebsites.net/api/v1/Users/8
- Заголовки запроса: -H  "accept: */*"
- Тело запроса (при наличии):
- Статус-код ответа: 200
- Тело ответа: {
  "id": 8,
  "userName": "User 8",
  "password": "Password8"
}

44.  ## HTTP-метод:  GET FAILED ​/api​/v1​/Users​/{88555551111111111111}
 - Полный URL запроса: https://fakerestapi.azurewebsites.net/api/v1/Users/88555551111111111111
- Заголовки запроса:  -H  "accept: */*"
- Тело запроса (при наличии):
- Статус-код ответа: 400
- Тело ответа: {
  "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
  "title": "One or more validation errors occurred.",
  "status": 400,
  "traceId": "00-fd8a51e4e4ac154a8c866448710328af-ace3cc86d144224d-00",
  "errors": {
    "id": [
      "The value '88555551111111111111' is not valid."
    ]
  }
}

