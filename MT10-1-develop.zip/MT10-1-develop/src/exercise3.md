## Описание объектов на примере сайта MVideo

### Local Storage

Ключ | Значение | Краткое описание |
| --- | --- | --- | 
| tmr_lvid | 	43e731f0d6367c6742cfdf72f3210037 | Идентификатор пользователя, который был назначен при посещении сайта |
| UXS_session_value | 531 | Показывает продолжительность сессии пользователя |
| suggestions-history | ``` [{"text":"iphone 11"},{"text":"samsung a04"},{"text":"samsung a32"}] ``` | Показывает историю поиска |
| statpolastPageViewsDate | 	2023-07-21 | Показывает дату посещения страницы |
| _ym25907066_il | "Смартфон Apple iPhone 11 64GB nanoSim/eSim Black" | Идентификатор в сервисе Яндекс.Метрика |


![Mvideo_1](src/images/Mvideo_1.jpg)


---

### Session Storage

Ключ | Значение | Краткое описание |
| --- | --- | --- | 
| AF_BANNERS_SESSION_ID | 1689957554184 | Используется для получения и сохранения прогресса действия пользователя на сайте |
| tabletConfirmationClosed | true | Используется для чтения значения данных, сохранённых в объекте sessionStorage|
| mvideo_url | https://www.mvideo.ru/ | Cтартовая страница веб-сайта |
| lastViewedCatalogPageUrl | /product-list-page?q=iphone+11&category=smartfony-205 | Используется для сохранения последней просмотренной страницы веб-сайта |
| gti | 1398e410-fbdb-e1d2-919b-5816b2bdf143 | Используется для получения глобального идентификатора, уникального для каждого посетителя сайта|


![Mvideo_2](src/images/Mvideo_2.jpg)


--- 

### Результат выполнения команд для добавления и получения объекта в "Session Storage"


![Mvideo_3](src/images/Mvideo_3.jpg)



### Состояние "Session Storage" после добавления объекта



![Mvideo_4](src/images/Mvideo_4.jpg)

---

### Результат выполнения команд для добавления и получения объекта в "Local Storage"

![Mvideo_5](src/images/Mvideo_5.jpg)


### Состояние "Local Storage" после добавления объекта

![Mvideo_6](src/images/Mvideo_6.jpg)

---
