# Activities

## 1. Activities: запрос на получение ресурса (GET ​/api​/v1​/Activities)

- **URL**: https://fakerestapi.azurewebsites.net/api/v1/Activities

- **Ожидаемый результат**: 
1. Статус-код ответа: 200
2. Схема JSON отображена корректно, имена и типы полей соответствуют ожидаемым.
Каждое поле JSON объекта соответствует аргументу метода сервиса

- **Заголовки запроса**:

```
User-Agent: PostmanRuntime/7.32.3
Accept: */*
Cache-Control: no-cache
Postman-Token: 62b749b6-8dca-45e8-ae05-e32f11108d1c
Host: fakerestapi.azurewebsites.net
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
```


- **Заголовки ответа**:

```
Content-Type: application/json; charset=utf-8; v=1.0
Date: Sat, 15 Jul 2023 19:09:36 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
```


- **Тело ответа**:

```
{
        "id": 1,
        "title": "Activity 1",
        "dueDate": "2023-07-15T20:36:27.9440348+00:00",
        "completed": false
    },
    {
        "id": 2,
        "title": "Activity 2",
        "dueDate": "2023-07-15T21:36:27.9440368+00:00",
        "completed": true
    },
    {
        "id": 3,
        "title": "Activity 3",
        "dueDate": "2023-07-15T22:36:27.9440371+00:00",
        "completed": false
},
```





## 2. Activities (+): запрос на создание нового ресурса без ошибок в теле (POST ​/api​/v1​/Activities)

- **URL**: https://fakerestapi.azurewebsites.net/api/v1/Activities

- **Ожидаемый результат**: 
1. Статус-код ответа: 201
2. Схема JSON отображена корректно, имена и типы полей соответствуют ожидаемым.
Каждое поле JSON объекта соответствует аргументу метода сервиса


- **Заголовки запроса**:

```
Content-Type: application/json
User-Agent: PostmanRuntime/7.32.3
Accept: */*
Cache-Control: no-cache
Postman-Token: 7f6d444c-b881-4a65-af93-e7760dc24c7c
Host: fakerestapi.azurewebsites.net
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
Content-Length: 99
```

- **Тело запроса**:

```
{
 "id": {{bad_id}},
 "title": "string",
 "dueDate": "2023-07-15T19:44:15.749Z",
 "completed": true
}
```


- **Заголовки ответа**:

```
Content-Type: application/json; charset=utf-8; v=1.0
Date: Sat, 15 Jul 2023 19:44:23 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
```


- **Тело ответа**:
```
{
    "id": 701,
    "title": "string",
    "dueDate": "2023-07-15T14:57:48.749Z",
    "completed": true
}
```






## 3. Activities (-): запрос на создание нового ресурса с синтаксической ошибкой в теле (POST ​/api​/v1​/Activities)

- **URL**: https://fakerestapi.azurewebsites.net/api/v1/Activities

- **Ожидаемый результат**:
1. Статус-код ответа: 400
2. В теле ответа в полях есть сообщение об ошибке
```
"title": "One or more validation errors occurred.",
"status": 400,
```

- **Заголовки запроса**:

```
Content-Type: application/json
User-Agent: PostmanRuntime/7.32.3
Accept: */*
Cache-Control: no-cache
Postman-Token: a02d10c4-7567-4602-a493-286b99186e13
Host: fakerestapi.azurewebsites.net
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
Content-Length: 98
```

- **Тело запроса**:

```
{
  "id": {{bad_id}},
 "title": string,
 "dueDate": "2023-07-15T10:57:48.749Z",
 "completed": true
}
```

- **Заголовки ответа**:

```
Content-Type: application/problem+json; charset=utf-8
Date: Sat, 15 Jul 2023 19:51:31 GMT
Server: Kestrel
Transfer-Encoding: chunked
```


- **Тело ответа**:

```
{
    "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
    "title": "One or more validation errors occurred.",
    "status": 400,
    "traceId": "00-0dc69220474a3c48b3a0100f2f0e8705-efac3fbc71dbf54b-00",
    "errors": {
        "$.title": [
            "'s' is an invalid start of a value. Path: $.title | LineNumber: 2 | BytePositionInLine: 10."
        ]
    }
}
```



## 4. Activities (-): запрос на создание нового ресурса с пустой строкой в теле (POST ​/api​/v1​/Activities)

- **URL**: https://fakerestapi.azurewebsites.net/api/v1/Activities

- **Ожидаемый результат**:
1. Статус-код ответа: 400
2. В теле ответа в полях есть сообщение об ошибке
```
"title": "One or more validation errors occurred.",
"status": 400,
```

- **Заголовки запроса**:

```
Content-Type: application/json
User-Agent: PostmanRuntime/7.32.3
Accept: */*
Cache-Control: no-cache
Postman-Token: ca493000-fa5b-4e99-97c0-68fa679cf09c
Host: fakerestapi.azurewebsites.net
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
Content-Length: 91
```

- **Тело запроса**:

```
{
 "id": {{bad_id}},
 "title": ,
 "dueDate": "2023-07-15T10:57:48.749Z",
 "completed": true
}
```

- **Заголовки ответа**:

```
Content-Type: application/problem+json; charset=utf-8
Date: Sat, 15 Jul 2023 19:58:28 GMT
Server: Kestrel
Transfer-Encoding: chunked
```


- **Тело ответа**:

```
{
    "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
    "title": "One or more validation errors occurred.",
    "status": 400,
    "traceId": "00-8d8731d6597cf9489647fc47837b10a2-403a2a83192cbf44-00",
    "errors": {
        "$.title": [
            "',' is an invalid start of a value. Path: $.title | LineNumber: 2 | BytePositionInLine: 10."
        ]
    }
}
```


## 5. Activities (-): запрос на создание нового ресурса с изменённым типом данных в теле (POST ​/api​/v1​/Activities)

- **URL**: https://fakerestapi.azurewebsites.net/api/v1/Activities

- **Ожидаемый результат**: 
1. Статус-код ответа: 400

2. В теле ответа в полях есть сообщение об ошибке
```
"title": "One or more validation errors occurred.",
"status": 400,
```

- **Заголовки запроса**:

```
Content-Type: application/json
User-Agent: PostmanRuntime/7.32.3
Accept: */*
Cache-Control: no-cache
Postman-Token: e9874dfc-b3b6-414f-bdab-4543776ecd80
Host: fakerestapi.azurewebsites.net
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
Content-Length: 94
```

- **Тело запроса**:

```
{
 "id": {{bad_id}},
 "title": {{bad_id}},
 "dueDate": "2023-07-15T10:57:48.749Z",
 "completed": true
}
```

- **Заголовки ответа**:

```
Response Headers
Content-Type: application/problem+json; charset=utf-8
Date: Sat, 15 Jul 2023 20:00:37 GMT
Server: Kestrel
Transfer-Encoding: chunked
```


- **Тело ответа**:

```
{
    "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
    "title": "One or more validation errors occurred.",
    "status": 400,
    "traceId": "00-366a157262974048adeb225a6f5cd83d-a625dfc5ecd61f42-00",
    "errors": {
        "$.title": [
            "The JSON value could not be converted to System.String. Path: $.title | LineNumber: 2 | BytePositionInLine: 13."
        ]
    }
}
```


## 6. Activities (+): запрос на получение ресурса с существующим ID (GET ​/api​/v1​/Activities​/{id})

- **URL**: https://fakerestapi.azurewebsites.net/api/v1/Activities/{{activity_id}}

- **Ожидаемый результат**:
1. Статус-код ответа: 200
2. Схема JSON отображена корректно, имена и типы полей соответствуют ожидаемым.
Каждое поле JSON объекта соответствует аргументу метода сервиса

- **Заголовки запроса**:

```
User-Agent: PostmanRuntime/7.32.3
Accept: */*
Cache-Control: no-cache
Postman-Token: bf09f68c-1927-4f2b-ab41-eff78b1a3613
Host: fakerestapi.azurewebsites.net
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
```


- **Заголовки ответа**:

```
Content-Type: application/json; charset=utf-8; v=1.0
Date: Sat, 15 Jul 2023 20:04:44 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
```


- **Тело ответа**:

```
{
    "id": 9,
    "title": "Activity 9",
    "dueDate": "2023-07-16T05:04:45.9822024+00:00",
    "completed": false
}
```


## 7. Activities (-): запрос на получение ресурса с несуществующим ID (GET​ /api​/v1​/Activities​/{id})

- **URL**: https://fakerestapi.azurewebsites.net/api/v1/Activities/{{bad_id}}

- **Ожидаемый результат**:
1. Статус-код ответа: 404
2. В теле ответа в полях есть сообщение об ошибке
```
"title": "Not Found",
"status": 404,
```

- **Заголовки запроса**:

```
User-Agent: PostmanRuntime/7.32.3
Accept: */*
Cache-Control: no-cache
Postman-Token: c1af7484-da5e-4f02-9219-eeaa887026cd
Host: fakerestapi.azurewebsites.net
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
```


- **Заголовки ответа**:

```
Content-Type: application/problem+json; charset=utf-8; v=1.0
Date: Sat, 15 Jul 2023 20:06:18 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
```


- **Тело ответа**:

```
{
    "type": "https://tools.ietf.org/html/rfc7231#section-6.5.4",
    "title": "Not Found",
    "status": 404,
    "traceId": "00-1152e7fb789ab4449041485ec122020a-9776a073457f5c48-00"
}
```










## 8. Activities (+): запрос на обновление существующего ресурса без ошибок в теле (PUT ​api/v1/Activities/{id})

- **URL**: https://fakerestapi.azurewebsites.net/api/v1/Activities/{{activity_id}}

- **Ожидаемый результат**:
1. Статус-код ответа: 200
2. Схема JSON отображена корректно, имена и типы полей соответствуют ожидаемым

- **Заголовки запроса**:

```
Content-Type: application/json
User-Agent: PostmanRuntime/7.32.3
Accept: */*
Cache-Control: no-cache
Postman-Token: 0f300f8a-40fc-4373-ba25-60607add6cdf
Host: fakerestapi.azurewebsites.net
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
Content-Length: 94
```

- **Тело запроса**:

```
{
 "id": {{activity_id}},
 "title": "Mir",
 "dueDate": "2023-07-15T04:56:16.517Z",
 "completed": true
}
```

- **Заголовки ответа**:

```
Content-Type: application/json; charset=utf-8; v=1.0
Date: Sat, 15 Jul 2023 20:12:20 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
```


- **Тело ответа**:
```
{
    "id": 9,
    "title": "Mir",
    "dueDate": "2023-07-15T04:56:16.517Z",
    "completed": true
}
```



## 9. Activities (-): запрос на обновление существующего ресурса с синтаксической ошибкой в теле (PUT  api/v1/Activities/{id})

- **URL**: https://fakerestapi.azurewebsites.net/api/v1/Activities/{{activity_id}}

- **Ожидаемый результат**:
1. Статус-код ответа: 400
2. В теле ответа в полях есть сообщение об ошибке
```
"title": "One or more validation errors occurred.",
"status": 400,
```


- **Заголовки запроса**:

```
Content-Type: application/json
User-Agent: PostmanRuntime/7.32.3
Accept: */*
Cache-Control: no-cache
Postman-Token: 2481f60b-9874-4b99-9485-0e92fa4c65f7
Host: fakerestapi.azurewebsites.net
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
Content-Length: 96
```

- **Тело запроса**:

```
{
 "id": {{activity_id}},
 "title": "string"
 "dueDate": "2023-07-15T11:13:56.181Z",
 "completed": true
}
```

- **Заголовки ответа**:

```
Content-Type: application/problem+json; charset=utf-8
Date: Sat, 15 Jul 2023 20:16:04 GMT
Server: Kestrel
Transfer-Encoding: chunked
```


- **Тело ответа**:

```
{
    "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
    "title": "One or more validation errors occurred.",
    "status": 400,
    "traceId": "00-3b73d7313422e34ba9e0b9a3638b3eaa-c45518a38c65854a-00",
    "errors": {
        "$": [
            "'\"' is invalid after a value. Expected either ',', '}', or ']'. Path: $ | LineNumber: 3 | BytePositionInLine: 1."
        ]
    }
}
```












## 10. Activities (-): запрос на обновление существующего ресурса с пустой строкой в теле (PUT ​ api/v1/Activities/{id})

- **URL**: https://fakerestapi.azurewebsites.net/api/v1/Activities/{{activity_id}}

- **Ожидаемый результат**:
1. Статус-код ответа: 400
2. В теле ответа в полях есть сообщение об ошибке
```
"title": "One or more validation errors occurred.",
"status": 400,
```

- **Заголовки запроса**:

```
Content-Type: application/json
User-Agent: PostmanRuntime/7.32.3
Accept: */*
Cache-Control: no-cache
Postman-Token: 01e112c2-b6f4-4e63-b81c-984285c0e224
Host: fakerestapi.azurewebsites.net
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
Content-Length: 89
```

- **Тело запроса**:

```
{
 "id": {{activity_id}},
 "title": ,
 "dueDate": "2023-07-15T11:13:56.181Z",
 "completed": true
}
```

- **Заголовки ответа**:

```
Content-Type: application/problem+json; charset=utf-8
Date: Sat, 15 Jul 2023 20:18:48 GMT
Server: Kestrel
Transfer-Encoding: chunked
```


- **Тело ответа**:

```
{
    "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
    "title": "One or more validation errors occurred.",
    "status": 400,
    "traceId": "00-61b01ac6684f084f8c6cde3aed6cbe00-07fbc0629adda442-00",
    "errors": {
        "$.title": [
            "',' is an invalid start of a value. Path: $.title | LineNumber: 2 | BytePositionInLine: 10."
        ]
    }
}
```







## 11. Activities (-): запрос на обновление существующего ресурса с изменённым типом данных в теле (PUT ​ api/v1/Activities/{id})

- **URL**: https://fakerestapi.azurewebsites.net/api/v1/Activities/{{activity_id}}

- **Ожидаемый результат**:
1. Статус-код ответа: 400
2. В теле ответа в полях есть сообщение об ошибке
```
"title": "One or more validation errors occurred.",
"status": 400,
```

- **Заголовки запроса**:

```
Content-Type: application/json
User-Agent: PostmanRuntime/7.32.3
Accept: */*
Cache-Control: no-cache
Postman-Token: 59ea6619-5e87-420b-9dd6-391654306798
Host: fakerestapi.azurewebsites.net
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
Content-Length: 92
```

- **Тело запроса**:

```
{
 "id": {{activity_id}},
 "title": {{activity_id}},
 "dueDate": "2023-07-15T11:13:56.181Z",
 "completed": true
}

```

- **Заголовки ответа**:

```
Content-Type: application/problem+json; charset=utf-8
Date: Sat, 15 Jul 2023 20:21:25 GMT
Server: Kestrel
Transfer-Encoding: chunked
```


- **Тело ответа**:

```
{
    "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
    "title": "One or more validation errors occurred.",
    "status": 400,
    "traceId": "00-75bac6fbb530054b9b5b43b9646ce396-bd405f9fb84ce142-00",
    "errors": {
        "$.title": [
            "The JSON value could not be converted to System.String. Path: $.title | LineNumber: 2 | BytePositionInLine: 11."
        ]
    }
}
```







## 12. Activities(+): запрос на удаление ресурса с существующим ID (DELETE ​/api​/v1​/Activities​/{id})

- **URL**: https://fakerestapi.azurewebsites.net/api/v1/Activities/{{activity_id}}

- **Ожидаемый результат**:
1. Статус-код ответа: 200
2. Схема JSON отображена корректно, имена и типы полей соответствуют ожидаемым.
Каждое поле JSON объекта соответствует аргументу метода сервиса

- **Заголовки запроса**:

```
User-Agent: PostmanRuntime/7.32.3
Accept: */*
Cache-Control: no-cache
Postman-Token: 16f74b54-2ca6-4fb1-af89-a2b40686e945
Host: fakerestapi.azurewebsites.net
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
```


- **Заголовки ответа**:

```
Content-Length: 0
Date: Sat, 15 Jul 2023 20:23:38 GMT
Server: Kestrel
api-supported-versions: 1.0
```









## 13. Activities (-): запрос на удаление ресурса с несуществующим ID (DELETE ​/api​/v1​/Activities​/{id})

- **URL**: https://fakerestapi.azurewebsites.net/api/v1/Activities/{{bad_id}}

- **Ожидаемый результат**:
1. Статус-код ответа: 404
2. В теле ответа в полях есть сообщение об ошибке
```
"title": "Not Found",
"status": 404,
```

- **Заголовки запроса**:

```
User-Agent: PostmanRuntime/7.32.3
Accept: */*
Cache-Control: no-cache
Postman-Token: d1c35df4-0958-46e6-92af-21f7ba15d4e6
Host: fakerestapi.azurewebsites.net
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
```

- **Заголовки ответа**:

```
Content-Type: application/problem+json; charset=utf-8; v=1.0
Date: Sat, 15 Jul 2023 20:27:15 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
```




# Authors

## 14. Authors: запрос на получение ресурса (GET ​/api​/v1​/Authors)

- **URL**: https://fakerestapi.azurewebsites.net/api/v1/Authors

- **Ожидаемый результат**:
1. Статус-код ответа: 200
2. Схема JSON отображена корректно, имена и типы полей соответствуют ожидаемым.
Каждое поле JSON объекта соответствует аргументу метода сервиса

- **Заголовки запроса**:

```
User-Agent: PostmanRuntime/7.32.3
Accept: */*
Cache-Control: no-cache
Postman-Token: 720ffa9f-e02e-49da-a5dd-1550149ad908
Host: fakerestapi.azurewebsites.net
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
```

- **Заголовки ответа**:

```
Content-Type: application/json; charset=utf-8; v=1.0
Date: Sat, 15 Jul 2023 21:25:06 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
```


- **Тело ответа**:

```
    {
        "id": 1,
        "idBook": 1,
        "firstName": "First Name 1",
        "lastName": "Last Name 1"
    },
    {
        "id": 2,
        "idBook": 1,
        "firstName": "First Name 2",
        "lastName": "Last Name 2"
    },
    {
        "id": 3,
        "idBook": 2,
        "firstName": "First Name 3",
        "lastName": "Last Name 3"
    },
    ....

```









## 15. Authors (+): запрос на создание нового ресурса (с несуществующим ID) без ошибок в теле (POST ​/api​/v1​/Authors)

- **URL**: https://fakerestapi.azurewebsites.net/api/v1/Authors

- **Ожидаемый результат**:
1. Статус-код ответа: 201
2. Схема JSON отображена корректно, имена и типы полей соответствуют ожидаемым.
Каждое поле JSON объекта соответствует аргументу метода сервиса

- **Заголовки запроса**:

```
Content-Type: application/json
User-Agent: PostmanRuntime/7.32.3
Accept: */*
Cache-Control: no-cache
Postman-Token: 64565166-2be8-40a8-bc67-0c85d625c865
Host: fakerestapi.azurewebsites.net
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
Content-Length: 103
```

- **Тело запроса**:

```
{
  "id": {{bad_id}},
  "idBook": {{bad_id}},
  "firstName": "First Name {{bad_id}}",
  "lastName": "Last Name {{bad_id}}"
}

```

- **Заголовки ответа**:

```
Content-Type: application/json; charset=utf-8; v=1.0
Date: Sat, 15 Jul 2023 21:28:23 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
```


- **Тело ответа**:

```
{
    "id": 701,
    "idBook": 701,
    "firstName": "First Name 701",
    "lastName": "Last Name 701"
}
```



## 16. Authors (-): запрос на создание нового ресурса (с несуществующим ID) с синтаксической ошибкой в теле (POST ​/api​/v1​/Authors)

- **URL**: https://fakerestapi.azurewebsites.net/api/v1/Authors

- **Ожидаемый результат**:
1. Статус-код ответа: 400
2. В теле ответа в полях есть сообщение об ошибке
```
"title": "One or more validation errors occurred.",
"status": 400,
```

- **Заголовки запроса**:

```
Content-Type: application/json
User-Agent: PostmanRuntime/7.32.3
Accept: */*
Cache-Control: no-cache
Postman-Token: e23c03bb-fedc-4245-a0b1-241c78e74e89
Host: fakerestapi.azurewebsites.net
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
Content-Length: 99
```

- **Тело запроса**:

```
{
  "id": {{bad_id}},
  "idBook": {{bad_id}},
  "firstName": First Name {{bad_id}},
  "lastName": "Last Name {{bad_id}}"
}
```

- **Заголовки ответа**:

```
Content-Type: application/problem+json; charset=utf-8
Date: Sat, 15 Jul 2023 21:30:51 GMT
Server: Kestrel
Transfer-Encoding: chunked
```


- **Тело ответа**:

```
{
    "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
    "title": "One or more validation errors occurred.",
    "status": 400,
    "traceId": "00-bc1ac5a137ba28458a23c3bf7c839be0-c8bdbfd5b71f994d-00",
    "errors": {
        "$.firstName": [
            "'F' is an invalid start of a value. Path: $.firstName | LineNumber: 3 | BytePositionInLine: 15."
        ]
    }
}
```






## 17.Authors (-): запрос на создание нового ресурса (с несуществующим ID) с пустой строкой в теле (POST ​/api​/v1​/Authors)

- **URL**: https://fakerestapi.azurewebsites.net/api/v1/Authors

- **Ожидаемый результат**:
1. Статус-код ответа: 400
2. В теле ответа в полях есть сообщение об ошибке
```
"title": "One or more validation errors occurred.",
"status": 400,
```

- **Заголовки запроса**:

```
Content-Type: application/json
User-Agent: PostmanRuntime/7.32.3
Accept: */*
Cache-Control: no-cache
Postman-Token: 244c1061-31c8-48c3-b9ba-d94562000e4f
Host: fakerestapi.azurewebsites.net
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
Content-Length: 89
```

- **Тело запроса**:

```
{
  "id": {{bad_id}},
  "idBook": {{bad_id}},
  "firstName": ,
  "lastName": "Last Name {{bad_id}}"
}
```

- **Заголовки ответа**:

```
Content-Type: application/problem+json; charset=utf-8
Date: Sat, 15 Jul 2023 21:34:24 GMT
Server: Kestrel
Transfer-Encoding: chunked
```


- **Тело ответа**:

```
{
    "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
    "title": "One or more validation errors occurred.",
    "status": 400,
    "traceId": "00-d2d827888fb94a47840fdc31f6249e01-94a30ce2feca0f4a-00",
    "errors": {
        "$.firstName": [
            "',' is an invalid start of a value. Path: $.firstName | LineNumber: 4 | BytePositionInLine: 15."
        ]
    }
}
```







## 18. Authors (-): запрос на создание нового ресурса (с несуществующим ID) с изменённым типом значений в теле (POST ​/api​/v1​/Authors)

- **URL**: https://fakerestapi.azurewebsites.net/api/v1/Authors

- **Ожидаемый результат**:
1. Статус-код ответа: 400
2. В теле ответа в полях есть сообщение об ошибке
```
"title": "One or more validation errors occurred.",
"status": 400,
```

- **Заголовки запроса**:

```
Content-Type: application/json
User-Agent: PostmanRuntime/7.32.3
Accept: */*
Cache-Control: no-cache
Postman-Token: b5b47768-32c8-4d83-9cd2-40bf3fc21fcc
Host: fakerestapi.azurewebsites.net
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
Content-Length: 101
```

- **Тело запроса**:

```
{
  "id": {{bad_id}},
  "idBook": {{bad_id}},
  "firstName": first Name {{bad_id}},
  "lastName": "Last Name {{bad_id}}"
}
```

- **Заголовки ответа**:

```
Content-Type: application/problem+json; charset=utf-8
Date: Sat, 15 Jul 2023 21:37:22 GMT
Server: Kestrel
Transfer-Encoding: chunked
```


- **Тело ответа**:

```
{
    "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
    "title": "One or more validation errors occurred.",
    "status": 400,
    "traceId": "00-5971cf6ef1bb8442ba4148a5f66ccf89-271956d50ec2a143-00",
    "errors": {
        "$.firstName": [
            "'first Name 701,\r\n  \"lastName\": \"Last Name 701\"\r\n\r\n}' is an invalid JSON literal. Expected the literal 'false'. Path: $.firstName | LineNumber: 3 | BytePositionInLine: 16."
        ]
    }
}
```






## 19. Authors (+): запрос на получение ресурса с существующим ID (GET /api/v1/Authors/authors/books/{idBook})

- **URL**: https://fakerestapi.azurewebsites.net/api/v1/Authors/authors/books/{{good_id}}

- **Ожидаемый результат**:
1. Статус-код ответа: 200
2. Схема JSON отображена корректно, имена и типы полей соответствуют ожидаемым.
Каждое поле JSON объекта соответствует аргументу метода сервиса

- **Заголовки запроса**:

```
User-Agent: PostmanRuntime/7.32.3
Accept: */*
Cache-Control: no-cache
Postman-Token: a471e983-56e7-4c57-8c84-f8e62c49ca06
Host: fakerestapi.azurewebsites.net
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
```


- **Заголовки ответа**:

```
Content-Type: application/json; charset=utf-8; v=1.0
Date: Sat, 15 Jul 2023 21:39:38 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
```


- **Тело ответа**:

```
[
    {
        "id": 579,
        "idBook": 200,
        "firstName": "First Name 579",
        "lastName": "Last Name 579"
    },
    {
        "id": 580,
        "idBook": 200,
        "firstName": "First Name 580",
        "lastName": "Last Name 580"
    },
    {
        "id": 581,
        "idBook": 200,
        "firstName": "First Name 581",
        "lastName": "Last Name 581"
    },
    {
        "id": 582,
        "idBook": 200,
        "firstName": "First Name 582",
        "lastName": "Last Name 582"
    }
]
```











## 20. Authors (-): запрос на получение ресурса с несуществующим ID (GET /api/v1/Authors/authors/books/{idBook})

- **URL**: https://fakerestapi.azurewebsites.net/api/v1/Authors/authors/books/{{bad_id}}

- **Ожидаемый результат**:
1. Статус-код ответа: 404
2. В теле ответа в полях есть сообщение об ошибке
```
"title": "Not Found",
"status": 404,
```

- **Заголовки запроса**:

```
User-Agent: PostmanRuntime/7.32.3
Accept: */*
Cache-Control: no-cache
Postman-Token: 498a59e4-6dd8-45b7-b374-3a5487bc9889
Host: fakerestapi.azurewebsites.net
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
```


- **Заголовки ответа**:

```
Content-Type: application/json; charset=utf-8; v=1.0
Date: Sat, 15 Jul 2023 21:41:56 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
```


- **Тело ответа**:

```
[]
```






## 21. Authors (+): запрос на получение ресурса с существующим ID (GET ​/api​/v1​/Authors​/{id})

- **URL**: https://fakerestapi.azurewebsites.net/api/v1/Authors/{{good_id}}

- **Ожидаемый результат**:
1. Статус-код ответа: 200
2. Схема JSON отображена корректно, имена и типы полей соответствуют ожидаемым.
Каждое поле JSON объекта соответствует аргументу метода сервиса

- **Заголовки запроса**:

```
User-Agent: PostmanRuntime/7.32.3
Accept: */*
Cache-Control: no-cache
Postman-Token: 6bc6b4ca-6bbd-44f7-9df7-522b6301ac31
Host: fakerestapi.azurewebsites.net
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
```


- **Заголовки ответа**:

```
Content-Type: application/json; charset=utf-8; v=1.0
Date: Sat, 15 Jul 2023 21:43:49 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
```


- **Тело ответа**:

```
{
    "id": 200,
    "idBook": 63,
    "firstName": "First Name 200",
    "lastName": "Last Name 200"
}
```






## 22. Authors (-): запрос на получение ресурса с несуществующим ID (GET ​/api​/v1​/Authors​/{id})

- **URL**: https://fakerestapi.azurewebsites.net/api/v1/Authors/{{bad_id}}

- **Ожидаемый результат**:
1. Статус-код ответа: 404
2. В теле ответа в полях есть сообщение об ошибке
```
"title": "Not Found",
"status": 404,
```

- **Заголовки запроса**:

```
User-Agent: PostmanRuntime/7.32.3
Accept: */*
Cache-Control: no-cache
Postman-Token: 32e39a5d-ce07-4962-87b3-7cb7daa8844f
Host: fakerestapi.azurewebsites.net
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
```


- **Заголовки ответа**:

```
Content-Type: application/problem+json; charset=utf-8; v=1.0
Date: Sat, 15 Jul 2023 21:45:17 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
```


- **Тело ответа**:

```
{
    "type": "https://tools.ietf.org/html/rfc7231#section-6.5.4",
    "title": "Not Found",
    "status": 404,
    "traceId": "00-04541ca24da7394b95d4e46ecd907e73-1b9e28fe42f7b243-00"
}
```





## 23. Authors (+): запрос на обновление существующего ресурса без ошибок в теле (PUT ​/api​/v1​/Authors​/{id})

- **URL**: https://fakerestapi.azurewebsites.net/api/v1/Authors/{{good_id}}

- **Ожидаемый результат**:
1. Статус-код ответа: 200
2. Схема JSON отображена корректно, имена и типы полей соответствуют ожидаемым.
Каждое поле JSON объекта соответствует аргументу метода сервиса

- **Заголовки запроса**:

```
Content-Type: application/json
User-Agent: PostmanRuntime/7.32.3
Accept: */*
Cache-Control: no-cache
Postman-Token: a06b8034-2469-4a25-a023-602d048dcaa8
Host: fakerestapi.azurewebsites.net
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
Content-Length: 86
```

- **Тело запроса**:

```
{
 "id": {{good_id}},
 "idBook": 0,
 "firstName": "Aleksandr",
 "lastName": "Pushkin"
}
```

- **Заголовки ответа**:

```
Content-Type: application/json; charset=utf-8; v=1.0
Date: Sat, 15 Jul 2023 21:47:35 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
```


- **Тело ответа**:

```
{
    "id": 200,
    "idBook": 0,
    "firstName": "Aleksandr",
    "lastName": "Pushkin"
}
```






## 24. Authors (-): запрос на обновление существующего ресурса с синтаксической ошибкой в теле (PUT ​/api​/v1​/Authors​/{id})

- **URL**: https://fakerestapi.azurewebsites.net/api/v1/Authors/{{good_id}}

- **Ожидаемый результат**:
1. Статус-код ответа: 400
2. В теле ответа в полях есть сообщение об ошибке
```
"title": "One or more validation errors occurred.",
"status": 400,
```

- **Заголовки запроса**:

```
Content-Type: application/json
User-Agent: PostmanRuntime/7.32.3
Accept: */*
Cache-Control: no-cache
Postman-Token: 7c52ca59-1227-4d9c-8cbd-62dc83a42298
Host: fakerestapi.azurewebsites.net
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
Content-Length: 82
```

- **Тело запроса**:

```
{
 "id": {{good_id}},
 "idBook": 0,
 "firstName": Aleksandr,
 "lastName": "Pushkin"
}
```

- **Заголовки ответа**:

```
Content-Type: application/problem+json; charset=utf-8
Date: Sat, 15 Jul 2023 21:50:15 GMT
Server: Kestrel
Transfer-Encoding: chunked
```


- **Тело ответа**:

```
{
    "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
    "title": "One or more validation errors occurred.",
    "status": 400,
    "traceId": "00-1f2f5e16f3206b479582085b99e6be10-ae94756f37cffb4d-00",
    "errors": {
        "$.firstName": [
            "'A' is an invalid start of a value. Path: $.firstName | LineNumber: 3 | BytePositionInLine: 14."
        ]
    }
}
```





## 25. Authors (-): запрос на обновление существующего ресурса с пустой строкой в теле (PUT ​/api​/v1​/Authors​/{id})

- **URL**: https://fakerestapi.azurewebsites.net/api/v1/Authors/{{good_id}}

- **Ожидаемый результат**:
1. Статус-код ответа: 400
2. В теле ответа в полях есть сообщение об ошибке
```
"title": "One or more validation errors occurred.",
"status": 400,
```
- **Заголовки запроса**:

```
Content-Type: application/json
User-Agent: PostmanRuntime/7.32.3
Accept: */*
Cache-Control: no-cache
Postman-Token: 58bd008e-0119-4867-9373-b7b75cd378ca
Host: fakerestapi.azurewebsites.net
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
Content-Length: 75
```

- **Тело запроса**:

```
{
 "id": {{good_id}},
 "idBook": 0,
 "firstName": ,
 "lastName": "Pushkin"
}

```

- **Заголовки ответа**:

```
Content-Type: application/problem+json; charset=utf-8
Date: Sat, 15 Jul 2023 21:52:19 GMT
Server: Kestrel
Transfer-Encoding: chunked
```


- **Тело ответа**:

```
{
    "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
    "title": "One or more validation errors occurred.",
    "status": 400,
    "traceId": "00-975f77888ace7445ad25ae25314ad6b2-312578a441176647-00",
    "errors": {
        "$.firstName": [
            "',' is an invalid start of a value. Path: $.firstName | LineNumber: 3 | BytePositionInLine: 14."
        ]
    }
}
```


## 26. Authors (-): запрос на обновление существующего ресурса с изменённым типом значений в теле (PUT ​/api​/v1​/Authors​/{id})

- **URL**: https://fakerestapi.azurewebsites.net/api/v1/Authors/{{good_id}}

- **Ожидаемый результат**:
1. Статус-код ответа: 400
2. В теле ответа в полях есть сообщение об ошибке
```
"title": "One or more validation errors occurred.",
"status": 400,
```

- **Заголовки запроса**:

```
Content-Type: application/json
User-Agent: PostmanRuntime/7.32.3
Accept: */*
Cache-Control: no-cache
Postman-Token: e2c1e104-2b7e-4fa3-b994-b9a3981ade83
Host: fakerestapi.azurewebsites.net
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
Content-Length: 78
```

- **Тело запроса**:

```
{
 "id": {{good_id}},
 "idBook": {{good_id}},
 "firstName": {{good_id}},
 "lastName": "Pushkin"
}
```

- **Заголовки ответа**:

```
Content-Type: application/problem+json; charset=utf-8
Date: Sat, 15 Jul 2023 21:54:31 GMT
Server: Kestrel
Transfer-Encoding: chunked

```


- **Тело ответа**:

```
{
    "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
    "title": "One or more validation errors occurred.",
    "status": 400,
    "traceId": "00-9f20f9d20eb1c04484fb74e67e69c38d-35be5d2804f13f4f-00",
    "errors": {
        "$.firstName": [
            "The JSON value could not be converted to System.String. Path: $.firstName | LineNumber: 3 | BytePositionInLine: 17."
        ]
    }
}
```



## 27.Authors (+): запрос на удаление ресурса с существующим ID (DELETE ​/api​/v1​/Authors​/{id})

- **URL**: https://fakerestapi.azurewebsites.net/api/v1/Authors/{{good_id}}

- **Ожидаемый результат**:
1. Статус-код ответа: 200
2. Схема JSON отображена корректно, имена и типы полей соответствуют ожидаемым.
Каждое поле JSON объекта соответствует аргументу метода сервиса

- **Заголовки запроса**:

```
User-Agent: PostmanRuntime/7.32.3
Accept: */*
Cache-Control: no-cache
Postman-Token: 525991fb-c8dd-4c7b-9d5d-c5efc3fcb176
Host: fakerestapi.azurewebsites.net
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
```


- **Заголовки ответа**:

```
Content-Length: 0
Date: Sat, 15 Jul 2023 21:56:21 GMT
Server: Kestrel
api-supported-versions: 1.0
```






## 28. Authors (-): запрос на удаление ресурса с несуществующим ID (DELETE ​/api​/v1​/Authors​/{id})

- **URL**: https://fakerestapi.azurewebsites.net/api/v1/Authors/{{bad_id}}

- **Ожидаемый результат**:
1. Статус-код ответа: 404
2. В теле ответа в полях есть сообщение об ошибке
```
"title": "Not Found",
"status": 404,
```


- **Заголовки запроса**:

```
User-Agent: PostmanRuntime/7.32.3
Accept: */*
Cache-Control: no-cache
Postman-Token: 3f9aca25-c33d-49ab-ad8b-16b2387677bb
Host: fakerestapi.azurewebsites.net
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
```


- **Заголовки ответа**:

```
Content-Length: 0
Date: Sat, 15 Jul 2023 21:58:02 GMT
Server: Kestrel
api-supported-versions: 1.0
```


# Books



## 29. Books: запрос на получение ресурса (GET ​/api​/v1​/Books)

- **URL**: https://fakerestapi.azurewebsites.net/api/v1/Books

- **Ожидаемый результат**:
1. Статус-код ответа: 200
2. Схема JSON отображена корректно, имена и типы полей соответствуют ожидаемым.
Каждое поле JSON объекта соответствует аргументу метода сервиса

- **Заголовки запроса**:

```
User-Agent: PostmanRuntime/7.32.3
Accept: */*
Cache-Control: no-cache
Postman-Token: 7d0a5337-b151-4dab-a988-5d42abc40daa
Host: fakerestapi.azurewebsites.net
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
```


- **Заголовки ответа**:

```
Content-Type: application/json; charset=utf-8; v=1.0
Date: Sat, 15 Jul 2023 22:04:39 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
```


- **Тело ответа**:

```

    {
        "id": 1,
        "title": "Book 1",
        "description": "Lorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\n",
        "pageCount": 100,
        "excerpt": "Lorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\n",
        "publishDate": "2023-07-14T22:04:40.0601208+00:00"
    },
    {
        "id": 2,
        "title": "Book 2",
        "description": "Lorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\n",
        "pageCount": 200,
        "excerpt": "Lorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\n",
        "publishDate": "2023-07-13T22:04:40.060138+00:00"
    },
    {
        "id": 3,
        "title": "Book 3",
        "description": "Lorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\n",
        "pageCount": 300,
        "excerpt": "Lorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\n",
        "publishDate": "2023-07-12T22:04:40.0601514+00:00"
    },
    ...
```


## 30. Books (+): запрос на создание нового ресурса (с несуществующим ID) без ошибок в теле (POST ​/api​/v1​/Books)

- **URL**: https://fakerestapi.azurewebsites.net/api/v1/Books

- **Ожидаемый результат**:
1. Статус-код ответа: 201
2. Схема JSON отображена корректно, имена и типы полей соответствуют ожидаемым.
Каждое поле JSON объекта соответствует аргументу метода сервиса

- **Заголовки запроса**:

```
Content-Type: application/json
User-Agent: PostmanRuntime/7.32.3
Accept: */*
Cache-Control: no-cache
Postman-Token: 576930ac-16e1-4cd6-9292-e2d453860eec
Host: fakerestapi.azurewebsites.net
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
Content-Length: 152
```

- **Тело запроса**:

```
{
 "id": {{bad_id}},
 "title": "string",
 "description": "string",
 "pageCount": 0,
 "excerpt": "string",
 "publishDate": "2023-07-15T08:19:26.282Z"
}

```

- **Заголовки ответа**:

```
Content-Type: application/json; charset=utf-8; v=1.0
Date: Sat, 15 Jul 2023 22:06:40 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
```


- **Тело ответа**:

```
{
    "id": 701,
    "title": "string",
    "description": "string",
    "pageCount": 0,
    "excerpt": "string",
    "publishDate": "2023-07-15T08:19:26.282Z"
}
```



## 31. Books (-): запрос на создание нового ресурса (с несуществующим ID) с синтаксической ошибкой в теле (POST ​/api​/v1​/Books)

- **URL**: https://fakerestapi.azurewebsites.net/api/v1/Books

- **Ожидаемый результат**:
1. Статус-код ответа: 400
2. В теле ответа в полях есть сообщение об ошибке
```
"title": "One or more validation errors occurred.",
"status": 400,
```

- **Заголовки запроса**:

```
Content-Type: application/json
User-Agent: PostmanRuntime/7.32.3
Accept: */*
Cache-Control: no-cache
Postman-Token: 3a201206-c455-422a-a055-864f8c1223c8
Host: fakerestapi.azurewebsites.net
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
Content-Length: 151
```

- **Тело запроса**:

```
{
 "id": {{bad_id}},
 "title": Tihiy Don,
 "description": "string",
 "pageCount": 0,
 "excerpt": "string",
 "publishDate": "2023-07-15T08:19:26.282Z"
}
```

- **Заголовки ответа**:

```
Content-Type: application/problem+json; charset=utf-8
Date: Sat, 15 Jul 2023 22:08:49 GMT
Server: Kestrel
Transfer-Encoding: chunked
```


- **Тело ответа**:

```
{
    "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
    "title": "One or more validation errors occurred.",
    "status": 400,
    "traceId": "00-a68927c1ff6bcb4c969b24f626a9335d-a189cb3c7b8c194c-00",
    "errors": {
        "$.title": [
            "'T' is an invalid start of a value. Path: $.title | LineNumber: 2 | BytePositionInLine: 10."
        ]
    }
}
```



## 32. Books (-): запрос на создание нового ресурса (с несуществующим ID) с пустой строкой в теле (POST ​/api​/v1​/Books)

- **URL**: https://fakerestapi.azurewebsites.net/api/v1/Books

- **Ожидаемый результат**:
1. Статус-код ответа: 400
2. В теле ответа в полях есть сообщение об ошибке
```
"title": "One or more validation errors occurred.",
"status": 400,
```


- **Заголовки запроса**:

```
Content-Type: application/json
User-Agent: PostmanRuntime/7.32.3
Accept: */*
Cache-Control: no-cache
Postman-Token: 1949def6-4e49-43ae-bf30-f17deebbcb2f
Host: fakerestapi.azurewebsites.net
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
Content-Length: 142
```

- **Тело запроса**:

```
{
 "id": {{bad_id}},
 "title": ,
 "description": "string",
 "pageCount": 0,
 "excerpt": "string",
 "publishDate": "2023-07-15T10:44:31.926Z"
}
```

- **Заголовки ответа**:

```
Content-Type: application/problem+json; charset=utf-8
Date: Sat, 15 Jul 2023 22:10:45 GMT
Server: Kestrel
Transfer-Encoding: chunked
```


- **Тело ответа**:

```
{
    "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
    "title": "One or more validation errors occurred.",
    "status": 400,
    "traceId": "00-f807127fadacdd42988d3f347ad4f342-42c83beb9bbcc345-00",
    "errors": {
        "$.title": [
            "',' is an invalid start of a value. Path: $.title | LineNumber: 2 | BytePositionInLine: 10."
        ]
    }
}
```







## 33. Books (+): запрос на получение ресурса с существующим ID (GET ​/api​/v1​/Books​/{id})

- **URL**: https://fakerestapi.azurewebsites.net/api/v1/Books/{{good_id}}

- **Ожидаемый результат**:
1. Статус-код ответа: 200
2. Схема JSON отображена корректно, имена и типы полей соответствуют ожидаемым.
Каждое поле JSON объекта соответствует аргументу метода сервиса

- **Заголовки запроса**:

```
User-Agent: PostmanRuntime/7.32.3
Accept: */*
Cache-Control: no-cache
Postman-Token: cfa9ac56-af0e-4a15-9287-01dc7de692f4
Host: fakerestapi.azurewebsites.net
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
```


- **Заголовки ответа**:

```
Content-Type: application/json; charset=utf-8; v=1.0
Date: Sat, 15 Jul 2023 22:12:14 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
```


- **Тело ответа**:

```
{
    "id": 200,
    "title": "Book 200",
    "description": "Lorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\n",
    "pageCount": 20000,
    "excerpt": "Lorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\n",
    "publishDate": "2022-12-27T22:12:15.9014967+00:00"
}
```



## 34. Books (-): запрос на получение ресурса с несуществующим ID (GET ​/api​/v1​/Books​/{id})

- **URL**: https://fakerestapi.azurewebsites.net/api/v1/Books/{{bad_id}}

- **Ожидаемый результат**:
1. Статус-код ответа: 404
2. В теле ответа в полях есть сообщение об ошибке
```
"title": "Not Found",
"status": 404,
```

- **Заголовки запроса**:

```
User-Agent: PostmanRuntime/7.32.3
Accept: */*
Cache-Control: no-cache
Postman-Token: 0c5599c5-15e6-4544-99af-ad942c535a26
Host: fakerestapi.azurewebsites.net
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
```



- **Заголовки ответа**:

```
Content-Type: application/problem+json; charset=utf-8; v=1.0
Date: Sat, 15 Jul 2023 22:13:37 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
```


- **Тело ответа**:

```
{
    "type": "https://tools.ietf.org/html/rfc7231#section-6.5.4",
    "title": "Not Found",
    "status": 404,
    "traceId": "00-4f1be20f0c61c7438f704f4da15f5595-5ed86a347f4fb04c-00"
}
```



## 35. Books (+): запрос на обновление существующего ресурса без ошибок в теле (PUT ​/api​/v1​/Books​/{id})

- **URL**: https://fakerestapi.azurewebsites.net/api/v1/Books/{{good_id}}

- **Ожидаемый результат**:
1. Статус-код ответа: 200
2. Схема JSON отображена корректно, имена и типы полей соответствуют ожидаемым.
Каждое поле JSON объекта соответствует аргументу метода сервиса

- **Заголовки запроса**:

```
Content-Type: application/json
User-Agent: PostmanRuntime/7.32.3
Accept: */*
Cache-Control: no-cache
Postman-Token: 3441319f-4b0e-4cfc-b564-e0126cf3339e
Host: fakerestapi.azurewebsites.net
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
Content-Length: 155
```

- **Тело запроса**:

```
{
 "id": {{good_id}},
 "title": "Tihiy don",
 "description": "string",
 "pageCount": 0,
 "excerpt": "string",
 "publishDate": "2023-07-15T08:51:14.962Z"
}
```

- **Заголовки ответа**:

```
Content-Type: application/json; charset=utf-8; v=1.0
Date: Sat, 15 Jul 2023 22:15:26 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
```


- **Тело ответа**:

```
{
    "id": 200,
    "title": "Tihiy don",
    "description": "string",
    "pageCount": 0,
    "excerpt": "string",
    "publishDate": "2023-07-15T08:51:14.962Z"
}
```




## 36. Books (-): запрос на обновление существующего ресурса с синтаксической ошибкой в теле (PUT ​/api​/v1​/Books​/{id})

- **URL**: https://fakerestapi.azurewebsites.net/api/v1/Books/{{good_id}}

- **Ожидаемый результат**:
1. Статус-код ответа: 400
2. В теле ответа в полях есть сообщение об ошибке
```
"title": "One or more validation errors occurred.",
"status": 400,
```

- **Заголовки запроса**:

```
Content-Type: application/json
User-Agent: PostmanRuntime/7.32.3
Accept: */*
Cache-Control: no-cache
Postman-Token: 64b7fcea-18ae-49ec-bf07-19b4825f5237
Host: fakerestapi.azurewebsites.net
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
Content-Length: 152
```

- **Тело запроса**:

```
{
 "id": {{good_id}},
 "title": "Tihiy don"
 "description": "string",
 "pageCount": 0,
 "excerpt": "string",
 "publishDate": "2023-07-15T08:51:14.962Z"
}
```

- **Заголовки ответа**:

```
Content-Type: application/problem+json; charset=utf-8
Date: Sat, 15 Jul 2023 22:17:35 GMT
Server: Kestrel
Transfer-Encoding: chunked
```


- **Тело ответа**:

```
{
    "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
    "title": "One or more validation errors occurred.",
    "status": 400,
    "traceId": "00-4f48f0c515d29f45aad3be44b8e9a25b-3b70b25431802c47-00",
    "errors": {
        "$": [
            "'\"' is invalid after a value. Expected either ',', '}', or ']'. Path: $ | LineNumber: 3 | BytePositionInLine: 1."
        ]
    }
}
```



## 37. Books (-): запрос на обновление существующего ресурса с изменённым типом значений в теле (PUT ​/api​/v1​/Books​/{id})

- **URL**: https://fakerestapi.azurewebsites.net/api/v1/Books/{{good_id}}

- **Ожидаемый результат**:
1. Статус-код ответа: 400
2. В теле ответа в полях есть сообщение об ошибке
```
"title": "One or more validation errors occurred.",
"status": 400,
```

- **Заголовки запроса**:

```
Content-Type: application/json
User-Agent: PostmanRuntime/7.32.3
Accept: */*
Cache-Control: no-cache
Postman-Token: 3530da8a-9763-49e3-9eaa-2a1afcbe1fcb
Host: fakerestapi.azurewebsites.net
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
Content-Length: 145
```

- **Тело запроса**:

```
{
 "id": {{good_id}},
 "title": {{good_id}},
 "description": "string",
 "pageCount": 0,
 "excerpt": "string",
 "publishDate": "2023-07-15T11:51:14.962Z"
}
```

- **Заголовки ответа**:

```
Content-Type: application/problem+json; charset=utf-8
Date: Sat, 15 Jul 2023 22:19:58 GMT
Server: Kestrel
Transfer-Encoding: chunked
```


- **Тело ответа**:

```
{
    "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
    "title": "One or more validation errors occurred.",
    "status": 400,
    "traceId": "00-6a7e4f94827f5b41b1da42e890065ca7-7be40e4e4d23ac43-00",
    "errors": {
        "$.title": [
            "The JSON value could not be converted to System.String. Path: $.title | LineNumber: 2 | BytePositionInLine: 13."
        ]
    }
}
```




## 38. Books (+): запрос на удаление ресурса с существующим ID (DELETE ​/api​/v1​/Books​/{id})

- **URL**: https://fakerestapi.azurewebsites.net/api/v1/Books/{{good_id}}

- **Ожидаемый результат**:
1. Статус-код ответа: 200
2. Схема JSON отображена корректно, имена и типы полей соответствуют ожидаемым.
Каждое поле JSON объекта соответствует аргументу метода сервиса

- **Заголовки запроса**:

```
User-Agent: PostmanRuntime/7.32.3
Accept: */*
User-Agent: PostmanRuntime/7.32.3
Accept: */*
Cache-Control: no-cache
Postman-Token: b15d04dd-e313-48b9-bab0-60146751ac3c
Host: fakerestapi.azurewebsites.net
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
```


- **Заголовки ответа**:

```
Content-Length: 0
Date: Sat, 15 Jul 2023 22:22:24 GMT
Server: Kestrel
api-supported-versions: 1.0
```






## 39. Authors (-): запрос на удаление ресурса с несуществующим ID (DELETE ​/api​/v1​/Books​/{id})

- **URL**: https://fakerestapi.azurewebsites.net/api/v1/Books/{{bad_id}}

- **Ожидаемый результат**:
1. Статус-код ответа: 404
2. В теле ответа в полях есть сообщение об ошибке
```
"title": "Not Found",
"status": 404,
```

- **Заголовки запроса**:

```
User-Agent: PostmanRuntime/7.32.3
Accept: */*
Cache-Control: no-cache
Postman-Token: 319a54ec-65c9-43c7-93c3-87d681f42321
Host: fakerestapi.azurewebsites.net
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
```

- **Заголовки ответа**:

```
Content-Length: 0
Date: Sat, 15 Jul 2023 22:23:28 GMT
Server: Kestrel
api-supported-versions: 1.0
```


# CoverPhotos

## 40. CoverPhotos: запрос на получение ресурса (GET ​/api​/v1​/CoverPhotos)

- URL: https://fakerestapi.azurewebsites.net/api/v1/CoverPhotos
- Ожидаемый результат:
1. Статус-код ответа: 200 
2. Схема JSON отображена корректно, имена и типы полей соответствуют ожидаемым.
Каждое поле JSON объекта соответствует аргументу метода сервиса
- Заголовки запроса:
```
User-Agent: PostmanRuntime/7.32.3
Accept: */*
Cache-Control: no-cache
Postman-Token: 62b749b6-8dca-45e8-ae05-e32f11108d1c
Host: fakerestapi.azurewebsites.net
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
```

- Заголовки ответа:
```
Content-Type: application/json; charset=utf-8; v=1.0
Date: Sat, 15 Jul 2023 19:09:36 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
```
- Тело ответа:
```
    {
        "id": 1,
        "idBook": 1,
        "url": "https://placeholdit.imgix.net/~text?txtsize=33&txt=Book 1&w=250&h=350"
    },
```

## 41. CoverPhotos (+): запрос на создание нового ресурса с несуществующим ID (POST ​/api​/v1​/CoverPhotos)

- URL: https://fakerestapi.azurewebsites.net/api/v1/CoverPhotos
- Ожидаемый результат:
1. Статус-код ответа: 201
2. Схема JSON отображена корректно, имена и типы полей соответствуют ожидаемым.
Каждое поле JSON объекта соответствует аргументу метода сервиса
- Заголовки запроса:
```
Content-Type: application/json
User-Agent: PostmanRuntime/7.32.3
Accept: */*
Postman-Token: 1d56132d-adf1-4fad-9c45-cfd1cd41e2f4
Host: fakerestapi.azurewebsites.net
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
Content-Length: 52
```
- Тело запроса:
```
{
 "id": {{bad_id}},
 "idBook": {{bad_id}},
 "url": "string"
}
```

- Заголовки ответа:
```
Content-Type: application/json; charset=utf-8; v=1.0
Date: Sat, 15 Jul 2023 20:03:07 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
```
- Тело ответа
```
{
    "id": 701,
    "idBook": 701,
    "url": "string"
}
```

## 42. CoverPhotos (-): запрос на создание нового ресурса с существующим ID (POST ​/api​/v1​/CoverPhotos)

- URL: https://fakerestapi.azurewebsites.net/api/v1/CoverPhotos
- Ожидаемый результат: 
1. Статус-код ответа: 409 / 400
2. В теле ответа в полях есть сообщение об ошибке 400 / 409
- Заголовки запроса:
```
Content-Type: application/json
User-Agent: PostmanRuntime/7.32.3
Accept: */*
Postman-Token: faac4d5d-1005-4c96-815b-270158abf4be
Host: fakerestapi.azurewebsites.net
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
Content-Length: 52
```
- Тело запроса:
```
{
 "id": {{good_id}},
 "idBook": {{good_id}},
 "url": "string"
}
```

- Заголовки ответа:
```
Content-Type: application/json; charset=utf-8; v=1.0
Date: Sat, 15 Jul 2023 20:27:11 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
```

- Тело ответа:
```
{
    "id": 200,
    "idBook": 200,
    "url": "string"
}
```

## 43. CoverPhotos (+): запрос на получение ресурса с существующим ID (GET ​/api​/v1​/CoverPhotos​/books​/covers​/{idBook})
- URL: https://fakerestapi.azurewebsites.net/api/v1/CoverPhotos/books/covers/{{good_id}}
- Ожидаемый результат:
1. Статус-код ответа: 200
2. Схема JSON отображена корректно, имена и типы полей соответствуют ожидаемым.
Каждое поле JSON объекта соответствует аргументу метода сервиса

- Заголовки запроса:
```
User-Agent: PostmanRuntime/7.32.3
Accept: */*
Postman-Token: cb640ff9-5ab4-4013-a786-5a36fb286efa
Host: fakerestapi.azurewebsites.net
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
```
- Заголовки ответа:
```
Content-Type: application/json; charset=utf-8; v=1.0
Date: Sat, 15 Jul 2023 20:44:34 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
```
- Тело ответа:
```
{
   "id": 200,
   "idBook": 200,
   "url": "https://placeholdit.imgix.net/~text?txtsize=33&txt=Book 200&w=250&h=350"
}
```

## 44. CoverPhotos​ (-): запрос на получение ресурса с несуществующим ID (GET ​/api​/v1​/CoverPhotos​/books​/covers​/{idBook})
- URL: https://fakerestapi.azurewebsites.net/api/v1/CoverPhotos/books/covers/{{bad_id}}
- Ожидаемый результат:
1. Статус-код ответа: 404
2. В теле ответа в полях есть сообщение об ошибке

- Заголовки запроса:
```
User-Agent: PostmanRuntime/7.32.3
Accept: */*
Cache-Control: no-cache
Postman-Token: eacca61c-d39c-4650-92eb-dd23170eee69
Host: fakerestapi.azurewebsites.net
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
```

- Заголовки ответа:
```
Content-Type: application/json; charset=utf-8; v=1.0
Date: Sun, 16 Jul 2023 07:52:25 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
```

- Тело ответа:
```
[]
```

## 45. CoverPhotos (+): запрос на получение ресурса с существующим ID (GET ​/api​/v1​/CoverPhotos​/{id})
- URL: https://fakerestapi.azurewebsites.net/api/v1/CoverPhotos/{{good_id}}
- Ожидаемый результат:
1. Статус-код ответа: 200
2. Схема JSON отображена корректно, имена и типы полей соответствуют ожидаемым.
Каждое поле JSON объекта соответствует аргументу метода сервиса

- Заголовки запроса:
```
User-Agent: PostmanRuntime/7.32.3
Accept: */*
Postman-Token: f150c8d4-5dec-4b10-8d54-c3f4e4e03624
Host: fakerestapi.azurewebsites.net
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
```

- Заголовки ответа:
```
Content-Type: application/json; charset=utf-8; v=1.0
Date: Sat, 15 Jul 2023 21:01:27 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
```

- Тело ответа:
```
{
    "id": 200,
    "idBook": 200,
    "url": "https://placeholdit.imgix.net/~text?txtsize=33&txt=Book 200&w=250&h=350"
}
```

## 46. CoverPhotos​(-): запрос на получение ресурса с несуществующим ID (GET ​/api​/v1​/CoverPhotos​/{id})
- URL: https://fakerestapi.azurewebsites.net/api/v1/CoverPhotos/{{bad_id}}
- Ожидаемый результат:
1. Статус-код ответа: 404
2. В теле ответа в полях есть сообщение об ошибке

- Заголовки запроса:
```
User-Agent: PostmanRuntime/7.32.3
Accept: */*
Cache-Control: no-cache
Postman-Token: 7105c9f7-0f2c-49bc-81cc-e34e6b33b9b7
Host: fakerestapi.azurewebsites.net
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
```

- Заголовки ответа:
```
Content-Type: application/problem+json; charset=utf-8; v=1.0
Date: Sat, 15 Jul 2023 21:08:10 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
```

- Тело ответа:
```
{
    "type": "https://tools.ietf.org/html/rfc7231#section-6.5.4",
    "title": "Not Found",
    "status": 404,
    "traceId": "00-f74b47b015f763458c15708a713545f0-655672523dc46a41-00"
}
```

## 47. CoverPhotos​ (+): запрос на обновление существующего ресурса без ошибок в теле (PUT ​/api​/v1​/CoverPhotos​/{id})
- URL: https://fakerestapi.azurewebsites.net/api/v1/CoverPhotos/{{good_id}}
- Ожидаемый результат:
1. Статус-код ответа: 200
2. Схема JSON отображена корректно, имена и типы полей соответствуют ожидаемым.
Каждое поле JSON объекта соответствует аргументу метода сервиса

- Заголовки запроса:
```
ontent-Type: application/json
User-Agent: PostmanRuntime/7.32.3
Accept: */*
Postman-Token: 88db6fd7-51e3-444d-853c-01b72160cdc3
Host: fakerestapi.azurewebsites.net
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
Content-Length: 54
```

- Тело запроса:
```
{
  "id": {{good_id}},
  "idBook": {{good_id}},
  "url": "Cover"
}
```

- Заголовки ответа:
```
Content-Type: application/json; charset=utf-8; v=1.0
Date: Sat, 15 Jul 2023 21:20:05 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
```

- Тело ответа:
```
{
    "id": 200,
    "idBook": 200,
    "url": "Cover"
}
``` 

## 48. CoverPhotos (-): запрос на обновление существующего ресурса с синтаксической ошибкой в теле (PUT ​/api​/v1​/CoverPhotos​/{id})
- URL: https://fakerestapi.azurewebsites.net/api/v1/CoverPhotos/{{good_id}}
- Ожидаемый результат:
1. Статус-код ответа: 400
2. В теле ответа в полях есть сообщение об ошибке

- Заголовки запроса:
```
Content-Type: application/json
User-Agent: PostmanRuntime/7.32.3
Accept: */*
Postman-Token: 8a9a1492-5d23-457a-b526-6560c54ffc3c
Host: fakerestapi.azurewebsites.net
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
Content-Length: 48
``` 

- Тело запроса:
```
{
 "id": {{good_id}},
 "idBook": {{good_id}}
 "url": Cover
}
```

- Заголовки ответа:
```
Content-Type: application/problem+json; charset=utf-8
Date: Sat, 15 Jul 2023 21:43:33 GMT
Server: Kestrel
Transfer-Encoding: chunked
```

- Тело ответа:
```
{
    "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
    "title": "One or more validation errors occurred.",
    "status": 400,
    "traceId": "00-74fd35e36b08fd44a6bd40d86ddc9cd1-d68ae3171002684a-00",
    "errors": {
        "$": [
            "'\"' is invalid after a value. Expected either ',', '}', or ']'. Path: $ | LineNumber: 3 | BytePositionInLine: 1."
        ]
    }
}
```

## 49. CoverPhotos (-): запрос на обновление существующего ресурса с изменённым типом данных в теле (PUT ​/api​/v1​/CoverPhotos​/{id})
- URL: https://fakerestapi.azurewebsites.net/api/v1/CoverPhotos/{{good_id}}
- Ожидаемый результат:
1. Статус-код ответа: 400
2. В теле ответа в полях есть сообщение об ошибке

- Заголовки запроса:
```
Content-Type: application/json
User-Agent: PostmanRuntime/7.32.3
Accept: */*
Cache-Control: no-cache
Postman-Token: a35a1946-10c1-4e96-822b-e090b439f5ac
Host: fakerestapi.azurewebsites.net
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
Content-Length: 47
```

- Тело запроса:
```
{
 "id": {{good_id}},
 "idBook": {{good_id}},
 "url": {{good_id}}
}
```

- Заголовки ответа:
```
Content-Type: application/problem+json; charset=utf-8
Date: Sun, 16 Jul 2023 07:55:51 GMT
Server: Kestrel
Transfer-Encoding: chunked
```

- Тело ответа:
```
{
    "id": 200,
    "idBook": 200,
    "url": "https://placeholdit.imgix.net/~text?txtsize=33&txt=Book 200&w=250&h=350"
}
```

## 50. CoverPhotos (+): запрос на удаление ресурса с существующим ID (DELETE ​/api​/v1​/CoverPhotos​/{id})
- URL: https://fakerestapi.azurewebsites.net/api/v1/CoverPhotos/{{good_id}}
- Ожидаемый результат:
1. Статус-код ответа: 200
2. Схема JSON отображена корректно, имена и типы полей соответствуют ожидаемым.
Каждое поле JSON объекта соответствует аргументу метода сервиса

- Заголовки запроса:
```
User-Agent: PostmanRuntime/7.32.3
Accept: */*
Postman-Token: b5167a9f-84d0-426a-812f-8fcda0d0bba6
Host: fakerestapi.azurewebsites.net
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
```

- Заголовки ответа:
```
Content-Length: 0
Date: Sat, 15 Jul 2023 22:15:49 GMT
Server: Kestrel
api-supported-versions: 1.0
```

## 51. CoverPhotos (-): запрос на удаление ресурса с несуществующим ID (DELETE ​/api​/v1​/CoverPhotos​/{id})
- URL: https://fakerestapi.azurewebsites.net/api/v1/CoverPhotos/{{bad_id}}
- Ожидаемый результат:
1. Статус-код ответа: 404
2. В теле ответа в полях есть сообщение об ошибке

- Заголовки запроса:
```
User-Agent: PostmanRuntime/7.32.3
Accept: */*
Postman-Token: 914e7106-21b7-4932-9909-7cfe8aa79aa1
Host: fakerestapi.azurewebsites.net
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
```

- Заголовки ответа:
```
Content-Length: 0
Date: Sat, 15 Jul 2023 22:23:21 GMT
Server: Kestrel
api-supported-versions: 1.0
```

# Users


## 52. Users: запрос на получение ресурса (GET ​/api​/v1​/Users)
- URL:https://fakerestapi.azurewebsites.net/api/v1/Users
- Ожидаемый результат:
1. Статус-код ответа: 200
2. Схема JSON отображена корректно, имена и типы полей соответствуют ожидаемым.

- Заголовки запроса:
```
User-Agent: PostmanRuntime/7.32.3
Accept: */*
Postman-Token: a46636e3-6b8c-4d43-a713-5f78fc12dda6
Host: fakerestapi.azurewebsites.net
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
```

- Заголовки ответа:
```
Content-Type: application/json; charset=utf-8; v=1.0
Date: Sat, 15 Jul 2023 22:33:59 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
```

- Тело ответа:
```
{
    "id": 1,
    "userName": "User 1",
    "password": "Password1"
}
```

## 53. Users (+): запрос на создание нового ресурса с несуществующим ID (POST ​/api​/v1​/Users)
- URL: https://fakerestapi.azurewebsites.net/api/v1/Users
- Ожидаемый результат:
1. Статус-код ответа: 201
2. Схема JSON отображена корректно, имена и типы полей соответствуют ожидаемым.

- Заголовки запроса:
```
Content-Type: application/json
User-Agent: PostmanRuntime/7.32.3
Accept: */*
Postman-Token: 9a9de102-1934-4933-b072-33d1fe3bb50b
Host: fakerestapi.azurewebsites.net
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
Content-Length: 62
```

- Тело запроса:
```
{
 "id": {{bad_id}},
 "userName": "Ron",
 "password": "terrier"
}
```

- Заголовки ответа:
```
Content-Type: application/json; charset=utf-8; v=1.0
Date: Sat, 15 Jul 2023 22:43:06 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
```

- Тело ответа:
```
{
    "id": 701,
    "userName": "Ron",
    "password": "terrier"
}
```

## 54. Users (-): запрос на создание нового ресурса с существующим ID (POST ​/api​/v1​/Users/{id})
- URL: https://fakerestapi.azurewebsites.net/api/v1/Users
- Ожидаемый результат:
1. Статус-код ответа: 400 / 409
2. В теле ответа в полях есть сообщение об ошибке 400 / 409

- Заголовки запроса:
```
Content-Type: application/json
User-Agent: PostmanRuntime/7.32.3
Accept: */*
Postman-Token: 816c4c91-775b-41ed-9068-f23465377538
Host: fakerestapi.azurewebsites.net
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
Content-Length: 61
```

- Тело запроса:
```
{
  "id": {{good_id}},
  "userName": "Snape",
  "password": "doe"
}
```

- Заголовки ответа:
```
Content-Type: application/json; charset=utf-8; v=1.0
Date: Sat, 15 Jul 2023 22:49:48 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
```

- Тело ответа:
```
{
    "id": 200,
    "userName": "Snape",
    "password": "doe"
}
```

## 55. Users (+): запрос на получение ресурса с существующим ID (GET ​/api​/v1​/Users​/{id})
- URL: https://fakerestapi.azurewebsites.net/api/v1/Users/{{activity_id}}
- Ожидаемый результат:
1. Статус-код ответа: 200
2. Схема JSON отображена корректно, имена и типы полей соответствуют ожидаемым

- Заголовки запроса:
```
User-Agent: PostmanRuntime/7.32.3
Accept: */*
Postman-Token: 7b57cbf1-f73f-477b-9c7a-ce4384e71c24
Host: fakerestapi.azurewebsites.net
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
```

- Заголовки ответа:
```
Content-Type: application/json; charset=utf-8; v=1.0
Date: Sat, 15 Jul 2023 22:55:43 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
```

- Тело ответа:
```
{
    "id": 9,
    "userName": "User 9",
    "password": "Password9"
}
```

## 56. Users (-): запрос на получение ресурса с несуществующим ID (GET ​/api​/v1​/Users​/{id})
- URL: https://fakerestapi.azurewebsites.net/api/v1/Users/{{bad_id}}
- Ожидаемый результат:
1. Статус-код ответа: 404
2. В теле ответа в полях есть сообщение об ошибке

- Заголовки запроса:
```
User-Agent: PostmanRuntime/7.32.3
Accept: */*
Postman-Token: 6e9d5654-1308-487f-a3f1-acf849b02bac
Host: fakerestapi.azurewebsites.net
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
```

- Заголовки ответа:
```
Content-Type: application/problem+json; charset=utf-8; v=1.0
Date: Sat, 15 Jul 2023 22:59:24 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
```

- Тело ответа:
```
{
    "type": "https://tools.ietf.org/html/rfc7231#section-6.5.4",
    "title": "Not Found",
    "status": 404,
    "traceId": "00-f326178d2071e843897a711ba8bb7c85-c3f937fc38f8ac4c-00"
}
```

## 57. Users (+): запрос на обновление существующего ресурса без ошибок в теле (PUT ​/api​/v1​/Users​/{id})
- URL: https://fakerestapi.azurewebsites.net/api/v1/Users/{{activity_id}}
- Ожидаемый результат:
1. Код-ответ: 200
2. Схема JSON отображена корректно, имена и типы полей соответствуют ожидаемым.

- Заголовки запроса:
```
Content-Type: application/json
User-Agent: PostmanRuntime/7.32.3
Accept: */*
Postman-Token: 6acdb121-5b86-4ada-a659-44facdd80045
Host: fakerestapi.azurewebsites.net
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
Content-Length: 62
```

- Тело запроса: 
```
{
  "id": {{activity_id}},
  "userName": "Harry",
  "password": "stag"
}
```

- Заголовки ответа:
```
Content-Type: application/json; charset=utf-8; v=1.0
Date: Sat, 15 Jul 2023 23:04:23 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
```

- Тело ответа:
```
{
    "id": 9,
    "userName": "Harry",
    "password": "stag"
}
```

## 58. Users (-): запрос на обновление существующего ресурса с синтаксической ошибкой в теле (PUT ​/api​/v1​/Users​/{id})
- URL: https://fakerestapi.azurewebsites.net/api/v1/Users/{{activity_id}}
- Ожидаемый результат:
1. Статус-код ответа: 400
2. В теле ответа в полях есть сообщение об ошибке

- Заголовки запроса:
```
Content-Type: application/json
User-Agent: PostmanRuntime/7.32.3
Accept: */*
Postman-Token: 707a3401-3b20-4ab1-b033-08cd47cd1225
Host: fakerestapi.azurewebsites.net
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
Content-Length: 63
```

- Тело запроса: 
```
{
  "id": {{activity_id}},
  "userName": "Harry",
  "password": "moony"
}
```

- Заголовки ответа:
```
Content-Type: application/json; charset=utf-8; v=1.0
Date: Sat, 15 Jul 2023 23:29:22 GMT
Server: Kestrel
Transfer-Encoding: chunked
api-supported-versions: 1.0
```

- Тело ответа:
```
{
    "id": 9,
    "userName": "Harry",
    "password": "moony"
}
```

## 59. Users (-): запрос на обновление существующего ресурса с изменённым типом данных в теле (PUT ​/api​/v1​/Users​/{id})
- URL: https://fakerestapi.azurewebsites.net/api/v1/Users/{{activity_id}}
- Ожидаемый результат:
1. Статус-код ответа: 400
2. В теле ответа в полях есть сообщение об ошибке

- Заголовки запроса:
```
Content-Type: application/json
User-Agent: PostmanRuntime/7.32.3
Accept: */*
Postman-Token: 1992d60f-7435-429f-96a4-98bc3b88dd48
Host: fakerestapi.azurewebsites.net
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
Content-Length: 57
```

- Тело запроса:
```
{
  "id": {{activity_id}},
  "userName": {{activity_id}},
  "password": "moony"
}
```

- Заголовки ответа:
```
Content-Type: application/problem+json; charset=utf-8
Date: Sat, 15 Jul 2023 23:35:06 GMT
Server: Kestrel
Transfer-Encoding: chunked
```

- Тело ответа:
```
{
    "type": "https://tools.ietf.org/html/rfc7231#section-6.5.1",
    "title": "One or more validation errors occurred.",
    "status": 400,
    "traceId": "00-0a144b03426c33468cf306842cac73c9-6b0a87d4a0454048-00",
    "errors": {
        "$.userName": [
            "The JSON value could not be converted to System.String. Path: $.userName | LineNumber: 2 | BytePositionInLine: 15."
        ]
    }
}
```

## 60. Users (+): запрос на удаление ресурса с существующим ID (DELETE ​/api​/v1​/Users​/{id})
- URL: https://fakerestapi.azurewebsites.net/api/v1/Users/{{activity_id}}
- Ожидаемый результат: 
1. Статус-код ответа: 200
2. Схема JSON отображена корректно, имена и типы полей соответствуют ожидаемым.

- Заголовки запроса:
```
User-Agent: PostmanRuntime/7.32.3
Accept: */*
Postman-Token: 2ca0c887-b96f-4aff-a3eb-8872d8675fa5
Host: fakerestapi.azurewebsites.net
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
```

- Заголовки ответа:
```
Content-Length: 0
Date: Sat, 15 Jul 2023 23:40:56 GMT
Server: Kestrel
api-supported-versions: 1.0
```

## 61. Users (-): запрос на удаление ресурса с несуществующим ID (DELETE ​/api​/v1​/Users​/{id})
- URL: https://fakerestapi.azurewebsites.net/api/v1/Users/{{bad_id}}
- Ожидаемый результат:
1. Статус-код ответа: 404
2. В теле ответа в полях есть сообщение об ошибке

- Заголовки запроса:
```
User-Agent: PostmanRuntime/7.32.3
Accept: */*
Postman-Token: 899d26d8-76ce-48c8-af24-9d611d4f7fca
Host: fakerestapi.azurewebsites.net
Accept-Encoding: gzip, deflate, br
Connection: keep-alive
```

- Заголовки ответа:
```
Content-Length: 0
Date: Sat, 15 Jul 2023 23:44:35 GMT
Server: Kestrel
api-supported-versions: 1.0
```