# XPath'ы для <a href="https://online.sber.insure/store/propertyins/">Сбербанк Страхование</a>


**Выбор полиса**
//div[@class='stepper__item ng-star-inserted stepper__item-active']

**Логотип «Сберстрахование"**
//div[@class='sber-logo']

# Кнопки

1. Квартира
//*[contains(text(),'Квартира')]/parent::button

2. Дом
//*[contains(text(),'Дом')]/parent::button

3. (Сдается в аренду) --- Да
//*_[contains(text(),'Сдается в')]/following::button[1]_

4. (Сдается в аренду) --- Нет
//*[contains(text(),'Сдается в')]/following::button[2]

5. (Расположена на 1 или посл.эт.)---  Да
//*[contains(text(),'Расположена')]/following::button[1]

6. (Расположена на 1 или посл.эт.) ---Нет
//*[contains(text(),'Расположена')]/following::button[2]

7. (Установлена охранная сигнализация) ---  Да
//*[contains(text(),'Установлена')]/following::button[1]

8. (Установлена охранная сигнализация) --- Нет  
//*[contains(text(),'Установлена')]/following::button[2]

9. (промокод) Применить
//*[contains(text(),'Применить')]/ancestor::button

### страница "Оформление"

10. Оформить
//*[contains(text(),'Оформить')]/ancestor::button

11. Заполнить по Сбер ID
//*[contains(text(),'Заполнить по Сбер ID')]/ancestor::button

12. Мужской
//*[contains(text(),'Мужской')]/ancestor::button

13. Женский
//*_[contains(text(),'Женский')]/ancestor::button_

14. Вернуться
//*[contains(text(),'Вернуться')]/parent::button

15. Оформить
//*[contains(text(),'Оформить')]/parent::button

# Чек-боксы 

1.. Отчество отсутствует
//*[text()='Отчество отсутствует']/ancestor::mat-checkbox

2. Улица отсутствует
//*[text()='Улица отсутствует']/ancestor::mat-checkbox

# Датапикеры

1.	Дата начала срока действия полиса

//button[@class='mat-focus-indicator mat-icon-button mat-button-base']

2.	Дата рождения

//button[@class='mat-focus-indicator mat-icon-button mat-button-base']

3.	Датапикер "Дата выдачи

//button[@class='mat-focus-indicator mat-icon-button mat-button-base'][last()]
 
 # Поля ввода

1. Срок действия страхования
//*_[@class="mat-form-field-infix ng-tns-c61-1"]_

2. Поле "Регион проживания"   
//*[contains(text(),'Регион проживания')]/ancestor::span

3. Поле "Промокод
//*[contains(text(),'Промокод')]/ancestor::span

4. Поле "Дата начала"
//*[contains(text(),'Дата начала')]/ancestor::span

5. Поле "Фамилия" 
//*[contains(text(),'Фамилия')]/ancestor::span

6. Поле "Отчество" 
//*[contains(text(),'Отчество')]/ancestor::span

7. Поле "Дата рождения" 
//*[contains(text(),'Дата рожения')]/ancestor::span

8. Поле "Имя" 
//*[contains(text(),'Имя')]/ancestor::span

9. Поле "Серия" 
//*[contains(text(),'Серия')]/ancestor::span

10. Поле "Номер"
//*[contains(text(),'Номер')]/ancestor::span
 
11. Поле "Дата выдачи"
 //*[contains(text(),'Дата выдачи')]/ancestor::span

12. Поле "Кем выдан" 
//*[contains(text(),'Кем выдан')]/ancestor::span

13. Поле "Код подразделения"
//*[contains(text(),'Код подразделения')]/ancestor::span

14. Поле "Регион"
//*[contains(text(),'Регион')]/ancestor::span

15. Поле "Город или населенный пункт"
//*[contains(text(),'Город или населенный пункт')]/ancestor::span

16. Поле "Улица"
//*[contains(text(),'Улица')]/ancestor::span

17. Поле "Дом, литера, корпус, строение" 
//*[contains(text(),'Дом, литера, корпус, строение')]/ancestor::span

18. Поле "Квартира"
//*[contains(text(),'Квартира')]/ancestor::span

19. Поле "Телефон"
//*[contains(text(),'Телефон')]/ancestor::span

20. Поле "Электронная почта"
//*[contains(text(),'Электронная почта')]/ancestor::span

21. Поле "Повтор электронной почты" 
//*[contains(text(),'Повтор электронной почты')]/ancestor::span

22. Дата рождения 
 //*[@class="mat-form-field-infix ng-tns-c61-7"]*

23. Дата выдачи
//*[@class="mat-form-field-infix ng-tns-c61-10"]

# Остальное

1. Слайдер в блоке выбора суммы
//* [@class="sbi-form__col-1"]

2. Хедер «Что будет застраховано?»
//*[text()='Что будет застраховано?']

3. Текстовый блок «Мебель, техника и ваши вещи»
//*[contains(text(),'Мебель, техника и ваши вещи')]/parent::div

4. Текстовый блок «Падение летательных аппаратов и их частей»
//*[contains(text(),'Падение летательных аппаратов и их частей')]/parent::div

5. Колонка «Чрезвычайная ситуация» 
//*[text()='Чрезвычайная ситуация']

6. Колонка «Стихийные бедствия»
//*[text()='Стихийные бедствия']
